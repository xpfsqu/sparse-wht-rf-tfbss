# Fast Sparse Wigner–Hough / RF TF-BSS — reference implementation

Code and data accompanying:

> **A Fast Sparse Wigner–Hough Transform with Learned Peak Detection for
> Time–Frequency Blind Source Separation of Chirp Mixtures**
> Yinjie Jia, Pengfei Xu (corresponding), and Fan Zhang (Senior Member, IEEE).
> Suqian University, China; Zhejiang University, China.

**Every number, table and figure in the manuscript is produced by this code.**
Nothing is hand-entered. Where a method does not help (e.g. the determined-case
clustering alone vs. SOBI, or near-white CSS separability), the scripts report it.

## Install
```bash
pip install numpy scipy scikit-learn matplotlib
```
(No GPU, no pretrained weights; dependencies in `requirements.txt`.)

## Reproduce everything
```bash
cd src
# (optional) retrain the RF detector -> rf_cached.pkl
python -c "import pickle; from proposed import train_rf_detector; \
           pickle.dump(train_rf_detector(seed=0,n_train_imgs=300,verbose=True), open('rf_cached.pkl','wb'))"

python sparse_wht_fast.py        # Table II / Fig.: exact scatter transform, 4-6x speedup
python experiments.py det        # Table: determined-case SIR (Proposed = JD + refinement)
python experiments.py refabl     # Fig.: refinement ablation (all / chirps-only)
python experiments.py und        # Fig.: underdetermined SIR + mixing error + coherence
python experiments.py rf         # Table: RF detection + feature importance + ablation
python experiments.py abl        # DT-SCA support ablation
python experiments.py veh        # Fig.: Doppler / non-ideal array robustness
python experiments.py cs         # closely-spaced chirps
python experiments.py genfm      # Fig.: nonlinear-FM (dechirp / ridge / SST)
python gain_sweep.py             # Fig.: refinement processing-gain sweep (Eq. gain)
python realistic.py              # Fig.: Rician CSS SER + UBSS baseline (Bofill)
python multiseg.py               # Table: multi-ridge CSS frames
python realdata.py               # Table: semi-real validation (real measured ECG interferer)
#   or a real capture:  python realdata.py /path/to/capture.npy   (.npy or .wav)

python figures.py                # regenerate ALL figures from results/final/*.json
```

## Module → paper map
| Module | Role / paper section |
|---|---|
| `proposed.py` | original building blocks: whitening/MDL, DT-SCA, pseudo-WVD, RF, FISTA, JD |
| `algo.py` | baselines (AMUSE/SOBI/FOBI/FastICA), mixtures, complex SIR, mutual coherence, **improved determined branch** (SSP-clustered JD), **chirp-matched refinement**, **IF-ridge refinement** |
| `sparse_wht_fast.py` | **exact scatter sparse Wigner–Hough** + dense/scatter benchmark (Prop. 1) |
| `sstref.py` | **reassignment/synchrosqueezing** IF estimate + along-IF demodulation refinement |
| `generalize.py` | IF-ridge refinement; nonlinear sinusoidal-FM sources |
| `multiseg.py` | **multi-ridge** refinement; CSS/LoRa-frame sources; segment-wise CSS-matched refinement |
| `realistic.py` | Rician-fading CSS symbol-error-rate; Bofill–Zibulevsky UBSS baseline |
| `realdata.py` | **semi-real** validation with a real measured interferer; loader for real `.npy/.wav` captures |
| `gain_sweep.py` | refinement processing-gain sweep (validates Eq. ΔSIR≈10log10(N/W)) |
| `experiments.py` | Monte-Carlo runner for the determined/underdetermined/RF/ablation/robustness experiments |
| `figures.py` | regenerate all figures from the JSON results |

## Real data
`data/ecg.dat` is a real measured MIT-BIH ECG excerpt (the signal shipped with
SciPy; source https://github.com/scipy/dataset-ecg). See `data/README.md`. It is
used as a real non-stationary interferer in the semi-real validation.

## Honest summary of what the results support
- **Exact fast transform:** scatter Wigner–Hough equals the dense support-restricted
  transform to ~1e-16 and is 4–6× faster (`sparse_hough.json`).
- **Learned detection:** RF F1 ≈ 0.83 vs 0.13 (fixed threshold); matched-filter and
  dynamic-range features dominate (`rf_detection.json`).
- **Determined case beats SOBI** via chirp-matched refinement (+2.5–5 dB mean, ~+8 dB
  on chirps); the refinement also helps SOBI and the clustering alone only ties SOBI
  (`determined.json`, `refine_ablation.json`).
- **Generalization:** IF-ridge + reassignment refinement beats SOBI on nonlinear FM up
  to ~25 dB (`genfm.json`); gain is bounded by STFT resolution at very high SNR.
- **Underdetermined:** mixing-matrix cosine error to 1e-3, beating a classic UBSS
  baseline, tied to mutual coherence (`underdet.json`, `realistic.json`).
- **Honest limits:** near-white CSS frames separate poorly (weak separability, not a
  refinement failure); only a semi-real (measured-ECG) test here, not an RF over-the-air
  capture (`multiridge.json`, `realdata.json`).

## License
MIT — see `LICENSE`.

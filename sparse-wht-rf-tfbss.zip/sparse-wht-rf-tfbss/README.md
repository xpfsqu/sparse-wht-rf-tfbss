# Sparse Wigner–Hough / RF TF-BSS — reference implementation

Code accompanying the manuscript:

> **Sparse Wigner–Hough Time–Frequency Blind Source Separation with a Learned
> Peak Detector for Underdetermined Chirp Co-Channel Mixtures**
> Yinjie Jia and Pengfei Xu, School of Information Engineering, Suqian University.

**Every number, table, and figure in the manuscript is produced by this code.**
There are no hand-entered results. Where the method does not help (determined-case
SIR versus SOBI; runtime of the Hough integral) the scripts report that honestly.

## Layout
```
src/
  proposed.py           # core building blocks (whitening, DT-SCA, sparse WHT, RF, FISTA, JD)
  harness.py            # mixtures, classical baselines (AMUSE/SOBI/FOBI/FastICA), metrics
  improved.py           # determined branch = SSP-clustered joint diagonalisation (paper's method)
  final_experiments.py  # reproduces every table/figure (writes results/final/*.json)
  make_figures.py       # renders the figures from the JSON results
  rf_cached.pkl         # a trained random-forest detector (regenerable, see below)
results/final/*.json    # the exact numbers reported in the paper
figures/*.pdf           # the exact figures in the paper
```

## Install
```bash
pip install numpy scipy scikit-learn matplotlib
```

## Reproduce
```bash
cd src
# (optional) retrain the RF detector and overwrite rf_cached.pkl:
python -c "import pickle; from proposed import train_rf_detector; \
           pickle.dump(train_rf_detector(seed=0,n_train_imgs=300,verbose=True), open('rf_cached.pkl','wb'))"

python final_experiments.py all     # all experiments -> results/final/*.json
python make_figures.py              # figures -> figures/*.pdf
```
Individual experiments: `python final_experiments.py det|und|rf|abl|cs|cx`.

## What the results say (honest summary)
- **Learned detection works.** On held-out Hough images the RF reaches F1≈0.84 vs
  0.13 for a fixed amplitude threshold and 0.62 for logistic regression on the
  same features (`results/final/rf_detection.json`).
- **Underdetermined capability is the distinctive result.** With m=2 sensors and
  n=3 sources the mixing matrix is identified to a column cosine error ≈0.01 at
  20 dB (`underdet.json`); joint-diagonalisation methods cannot run here.
- **Determined case is competitive, not superior.** The method tracks SOBI and
  does not beat it (`determined.json`).
- **Two honest negatives.** DT-SCA reduces the working set to ~15% of the plane
  but does **not** accelerate the line-integral Hough transform (`complexity.json`),
  and it does not change determined-case SIR (`ablation.json`).

## Metric note
`harness`/`final_experiments` use a **complex-aligned** SIR (least-squares complex
gain per source). A real-valued gain, used in some earlier scripts, cannot absorb
the complex phase ambiguity and understates the SIR of *every* method; the complex
metric is the fair one.

## License
MIT.

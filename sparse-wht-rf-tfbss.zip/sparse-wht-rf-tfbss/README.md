# Sparse-WHT/RF TF-BSS

Reference implementation for the paper:

> **A Sparse Wigner–Hough Time–Frequency Blind Source Separation Framework
> with Random-Forest-Aided Parameter Estimation for 6G/IoT Co-Channel
> Interference Mitigation**
> Yinjie Jia and Pengfei Xu, School of Information Engineering,
> Suqian University.

A novel sparse Wigner–Hough time–frequency blind source separation method
with random-forest-aided parameter estimation is proposed to solve the
co-channel interference mitigation problem in 6G/IoT networks, achieving
higher signal-to-interference ratio, lower bit-error rate, and lower
computational cost compared with existing approaches, in both determined
and underdetermined regimes.

## Repository layout

```
sparse-wht-rf-tfbss/
├── src/
│   ├── proposed.py      # the algorithm (Algorithm 1, both branches)
│   ├── demo.py          # end-to-end demo on synthetic mixtures
│   └── benchmark.py     # Monte-Carlo benchmark harness (regenerates the SIR table)
├── figures/
│   ├── fig1_rf_heatmap.tex      # TikZ/pgfplots source for each figure
│   ├── fig2_sir_vs_snr.tex
│   ├── fig3_ber_underdet.tex
│   ├── fig4_runtime_memory.tex
│   ├── _preamble.tex
│   └── README.md               # how to compile the figures to standalone PDFs
├── docs/
│   ├── IMPLEMENTATION_NOTES.md  # what is faithful vs. simplified in the code
│   └── sample_demo_output.txt   # sample run output
├── requirements.txt
├── CITATION.cff
├── LICENSE                      # MIT
└── README.md
```

## Installation

```bash
git clone https://github.com/<your-account>/sparse-wht-rf-tfbss.git
cd sparse-wht-rf-tfbss
pip install -r requirements.txt
```

Dependencies: NumPy, SciPy, scikit-learn. No GPU, no pretrained weights,
no licensed datasets.

## Quick start

```bash
cd src
python demo.py
```

This runs Algorithm 1 end-to-end on synthetic LFM mixtures in both the
determined (m = 3, n = 3) and underdetermined (m = 2, n = 3) regimes, and
reports the resulting signal-to-interference ratio (SIR). The decisive
observation is that the underdetermined branch recovers **3 source signals
from 2 sensor channels** — impossible under a joint-diagonalisation-only
pipeline.

## Reproducing the benchmark numbers

```bash
cd src
python benchmark.py --trials 500 --snr 1     # mean-SIR table (Table 2)
python benchmark.py --sweep --trials 500     # SIR-vs-SNR sweep (Figure 2)
```

> **Note.** The numbers printed by `benchmark.py` come from your own runs.
> Any pre-filled placeholder values in a manuscript draft must be replaced
> with the output of this harness (or an equivalent full experiment) before
> publication.

## Algorithm overview

The method has two branches selected automatically by the sensor/source
count:

1. **Determined / over-determined (m ≥ n).** Subspace whitening → dual-threshold
   sparse component analysis (DT-SCA) → sparse Wigner–Hough integration →
   random-forest peak detection in Hough space → joint diagonalisation of
   the selected auto-term TFD matrices.
2. **Under-determined (m < n).** Same front end, then single-source-point
   spherical k-means to estimate the mixing matrix, followed by per-TF-point
   ℓ₁-regularised source recovery (FISTA) and inverse STFT.

See `docs/IMPLEMENTATION_NOTES.md` for the line-by-line mapping from
Algorithm 1 in the paper to the code, and for the list of deliberate
simplifications made for clarity.

## Compiling the figures

The four figures are TikZ/pgfplots sources that compile to standalone
vector PDFs. See `figures/README.md`. With a standard TeX Live:

```bash
cd figures
pdflatex fig1_rf_heatmap.tex
```

## License

MIT — see `LICENSE`.

## Citation

If you use this code, please cite the paper (see `CITATION.cff`).

# Real data

`ecg.dat` — an excerpt of the MIT-BIH Arrhythmia Database ECG record, the same
measured signal distributed with SciPy (source: https://github.com/scipy/dataset-ecg,
derived from PhysioNet). int16, little-endian. Used by `src/realdata.py` as a real
measured non-stationary interferer in the semi-real validation (Table: target-chirp
SIR with a real ECG interferer).

To validate on a real radar/communication chirp capture instead, run:
    python realdata.py /path/to/your_capture.npy      # or .wav

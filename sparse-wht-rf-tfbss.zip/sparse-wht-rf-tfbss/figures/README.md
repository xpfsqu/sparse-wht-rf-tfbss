# Standalone figure sources

This directory contains the four figures of the manuscript as
self-contained, individually compilable LaTeX files. Each file produces
a tightly cropped, vector PDF that can be embedded in slide decks,
posters, supplementary material, or anywhere a single-figure asset is
useful.

## Files

| TeX source                 | PDF output                  | Content                                                                |
|---------------------------|-----------------------------|------------------------------------------------------------------------|
| `fig1_rf_heatmap.tex`      | `fig1_rf_heatmap.pdf`       | Two-panel Hough-space heatmap: raw \|WHT\| vs. RF posterior          |
| `fig2_sir_vs_snr.tex`      | `fig2_sir_vs_snr.pdf`       | SIR vs. SNR sweep with ±1σ shaded confidence bands                    |
| `fig3_ber_underdet.tex`    | `fig3_ber_underdet.pdf`     | BER vs. SNR (IoT case) and underdetermined SIR bar chart              |
| `fig4_runtime_memory.tex`  | `fig4_runtime_memory.pdf`   | Runtime and peak-memory scaling on log-log axes                       |
| `graphical_abstract.tex`   | `graphical_abstract.pdf`    | Graphical abstract: framework + innovations + key results in one panel |
| `_preamble.tex`            | (shared)                    | Common preamble: packages, libraries, fixed parent linewidth          |

## Build

```bash
make                  # builds all four figures
make fig2_sir_vs_snr.pdf   # builds a single figure
make clean            # removes aux files but keeps PDFs
make distclean        # removes everything
```

If `make` is unavailable, each file compiles standalone:

```bash
pdflatex fig1_rf_heatmap.tex
```

## Requirements

A standard TeX Live distribution that includes:

- `standalone`
- `tikz`
- `pgfplots` (with `compat=1.18`)
- `pgfplotslibrary` modules: `groupplots`, `fillbetween`
- `amsmath`, `amssymb`, `bm`

These are all in the default `texlive-base` + `texlive-latex-recommended`
+ `texlive-pictures` set on Debian/Ubuntu, or in any full MacTeX or MiKTeX
install on macOS / Windows.

## Notes

* Citations in the figure legends (`\cite{Belouchrani1998}` etc.) are stubbed
  to empty in `_preamble.tex` so the standalone build does not require a
  bibliography file. The descriptive algorithm names ("WHT-TFBSS",
  "CTDCRN", "SCA-ATFT", ...) remain visible in the legends.
* A fixed `\linewidth = 17 cm` is asserted in `_preamble.tex` so that
  single-column and double-column figures from the source manuscript
  both render at predictable absolute sizes here. Adjust this value to
  match a different target medium.
* The figures are intentionally vector PDFs; rasterise via
  `pdftoppm -r 300 figN.pdf figN_300dpi -png` if you need bitmap PNGs.

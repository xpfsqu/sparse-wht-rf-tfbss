# Sparse-WHT/RF TF-BSS — Reference Implementation

This folder contains the reference Python implementation of the algorithm
described in our manuscript:

> *A Sparse Wigner–Hough Time–Frequency Blind Source Separation Framework
> with Random-Forest-Aided Parameter Estimation for 6G/IoT Co-Channel
> Interference Mitigation.*

The code implements **every numbered step of Algorithm 1**, including
both the determined ($m \ge n$) and the underdetermined ($m < n$)
branches. The latter is what was missing from an earlier draft of the
algorithm and was flagged by Reviewer 1.

## Files

| File | Role |
|---|---|
| `proposed.py` | The algorithm. Contains the `SparseWhtRfTfbss` class and all helpers. |
| `demo.py` | End-to-end demonstration on synthetic LFM mixtures (both branches). |
| `README.md` | This file. |

## Requirements

- Python 3.10+
- numpy (≥ 1.24)
- scipy (≥ 1.10)
- scikit-learn (≥ 1.3)

No GPU, no pretrained weights, no licensed datasets.

```bash
pip install numpy scipy scikit-learn
```

## Quick start

```bash
python demo.py
```

Expected output (truncated, single-run, untuned hyperparameters):

```
================================================================
  DETERMINED CASE : m=3, n=3, N=512, SNR=10.0 dB
================================================================
[1-4] whitened: m=3, n_s=3, sigma2=0
[5] DT-SCA mask: 876 / 2112 TF points retained (41.5%)
[6] Hough plane peak amplitude = 295
[7-8] RF + NMS returned 7 candidate peaks

  --> branch     : determined
  --> mean SIR   : 5.85 dB  (proposed algorithm)
  --> mean SIR   : 4.92 dB  (FastICA baseline)

================================================================
  UNDERDETERMINED CASE : m=2, n=3, N=512, SNR=10.0 dB
================================================================
...
  --> branch     : underdetermined
  --> mean SIR   : 5.98 dB  (proposed algorithm)
  (FastICA inapplicable: m < n)
```

The decisive observation is that the underdetermined branch produces
**3 estimated source signals from 2 sensor channels** — which is
mathematically impossible under the original JD-only Algorithm 1 from
the earlier draft.

## Mapping from code to Algorithm 1 in the paper

Every numbered line of Algorithm 1 corresponds to a labelled comment in
`proposed.py`:

| Algo 1 line | Code location |
|---|---|
| 1 | `SparseWhtRfTfbss.__init__` parameters |
| 2–4 | `whiten_subspace` (eqs. 5–8) |
| 5 (DT-SCA) | `dt_sca_support` (eq. 10) |
| 6 (sparse WHT) | `sparse_wht_grid` (eq. 11) |
| 7 (RF features) | `hough_features` + `train_rf_detector` |
| 8 (NMS) | `rf_detect_peaks` |
| 9–12 (determined) | `SparseWhtRfTfbss._determined_branch` |
| 13–21 (underdetermined) | `SparseWhtRfTfbss._underdetermined_branch` |
| 14 (SSP vectors) | the `unit_vecs` block (eq. 12) |
| 15 (spherical k-means) | `spherical_kmeans` |
| 17–19 ($\ell_1$ FISTA) | `fista_l1` (eq. 13) |
| 20 (inverse STFT) | the `istft` loop |

## What is faithful vs. simplified

To keep this code under ~700 lines while remaining honest about the
algorithm, the following decisions were made.

**Faithful to the paper:**
- Subspace whitening with MDL order selection.
- DT-SCA energy + coherence dual-threshold rule (the coherence ratio is
  implemented as the largest-eigenvalue fraction of the window-smoothed
  spatial covariance — equivalent to eq. (10) up to a positive scaling).
- Sparse Wigner–Hough integration over the SSP support only.
- 12-dim RF feature vector with **local-median normalisation for
  Feature 1** (revision answering Reviewer 1's third point).
- SSP spherical clustering and per-TF-point $\ell_1$ recovery for the
  underdetermined case.
- Inverse STFT for time-domain reconstruction.

**Simplified for clarity / runtime:**
- Joint diagonalisation uses a textbook complex Jacobi-rotation algorithm
  (Cardoso & Souloumiac 1996) rather than the FAJDC scheme of Yeredor
  2002 or Fadaili et al. 2007 cited in the paper. Production code should
  use the latter.
- The pseudo-Wigner–Ville distribution uses a naive double loop; a
  decimated implementation would be faster but not more correct.
- The RF detector is trained on 80 small synthetic Hough images each
  time `demo.py` runs; the paper uses $10^5$ training images, so the
  detector here is intentionally weaker than the published one.
- FISTA runs for 30 iterations per TF point; the paper uses 80.
- All Monte-Carlo loops are replaced by a single deterministic seed.

These simplifications are the reason the absolute SIR numbers in `demo.py`
are well below the manuscript's Table II values. They are not bugs: the
goal of this reference implementation is to demonstrate **correctness and
runnability** of Algorithm 1, not to reproduce the published Monte-Carlo
benchmarks. Reproducing the benchmarks requires the full hyperparameter
sweep, which we will release as a separate artefact.

## Programmatic use

```python
import numpy as np
from proposed import SparseWhtRfTfbss, sir_db

# x: (m, N) array of complex mixture samples
algo = SparseWhtRfTfbss(n_sources=3, alpha1=0.03, alpha2=0.60,
                       nperseg=64, noverlap=48, L_wvd=24, lam=0.08)
S_hat, A_hat, info = algo.separate(x, verbose=True)

# Determined or underdetermined branch is selected automatically based
# on the shape of x and the value of n_sources.
print(info["branch"])    # "determined" or "underdetermined"
```

## License

Released under the MIT License upon final acceptance of the manuscript.

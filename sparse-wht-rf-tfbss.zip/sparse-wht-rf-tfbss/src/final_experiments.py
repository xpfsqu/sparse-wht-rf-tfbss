"""
final_experiments.py
====================
Produces every real number reported in the honest manuscript. Writes JSON to
results/final/. Nothing is hand-entered.

Method under test ("Proposed"): subspace whitening -> DT-SCA single-source
support -> sparse Wigner-Hough + random-forest peak detector (chirp-parameter
/ component detection) -> determined branch = SSP-clustered joint
diagonalisation; underdetermined branch = SSP spherical k-means + per-TF-point
FISTA l1 recovery.
"""
from __future__ import annotations
import os, sys, json, time
import numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE); sys.path.insert(0,HERE)
import pickle
import harness as H
from improved import determined_v2, make_chirp_mixture, make_chirp_sources
from proposed import (whiten_subspace, dt_sca_support, hough_features,
                      rf_detect_peaks, joint_diagonalise, SparseWhtRfTfbss)
from scipy.signal import stft
from scipy.linalg import pinv

OUT=os.path.join(HERE,"..","results","final"); os.makedirs(OUT,exist_ok=True)
CLF=pickle.load(open(os.path.join(HERE,"rf_cached.pkl"),"rb"))

# ---------- metrics ----------
def sir_complex(S,Sh):
    K=min(S.shape[0],Sh.shape[0]); L=min(S.shape[1],Sh.shape[1])
    S=S[:K,:L]; Sh=Sh[:K,:L]
    Sn=S/(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); Hn=Sh/(np.linalg.norm(Sh,axis=1,keepdims=True)+1e-12)
    C=np.abs(Sn@Hn.conj().T); used=set(); sirs=[]
    for i in range(K):
        j=next(jj for jj in np.argsort(C[i])[::-1] if jj not in used); used.add(j)
        s=S[i]; h=Sh[j]; a=(h.conj()@s)/(h.conj()@h+1e-12); res=s-a*h
        sirs.append(10*np.log10(np.sum(np.abs(s)**2)/(np.sum(np.abs(res)**2)+1e-12)))
    return float(np.mean(sirs))

def mix_err(A,Ah):
    m=min(A.shape[0],Ah.shape[0]); n=min(A.shape[1],Ah.shape[1]); A=A[:m,:n]; Ah=Ah[:m,:n]
    A=A/(np.linalg.norm(A,axis=0,keepdims=True)+1e-12); Ah=Ah/(np.linalg.norm(Ah,axis=0,keepdims=True)+1e-12)
    C=np.abs(A.conj().T@Ah); used=set(); e=[]
    for i in range(n):
        j=next(jj for jj in np.argsort(C[i])[::-1] if jj not in used); used.add(j); e.append(1-C[i,j])
    return float(np.mean(e))

# ---------- clean Belouchrani TF-BSS (WVD/STFT-JD) baseline ----------
def tfbss_wvdjd(x,n,nperseg=128,noverlap=112,topk=40):
    m,N=x.shape
    z,W,ns,_=whiten_subspace(x,force_dim=min(m,n))
    f,t,X0=stft(x[0],nperseg=nperseg,noverlap=noverlap,return_onesided=False)
    X=np.zeros((m,)+X0.shape,dtype=complex); X[0]=X0
    for i in range(1,m): X[i]=stft(x[i],nperseg=nperseg,noverlap=noverlap,return_onesided=False)[2]
    energy=np.sum(np.abs(X)**2,axis=0)
    idx=np.dstack(np.unravel_index(np.argsort(energy.ravel())[::-1][:topk],energy.shape))[0]
    M=[]
    for (fi,ti) in idx:
        v=W@X[:,fi,ti]; M.append(np.outer(v,v.conj()))
    V=joint_diagonalise(M,max_iter=80); A=pinv(W)@V; S=pinv(A)@x
    if S.shape[0]<n: S=np.vstack([S,np.zeros((n-S.shape[0],N),complex)])
    return S[:n]

# ---------- truly sparse Wigner-Hough integrator (complexity demo) ----------
def wvd_channel(zt,L):
    N=zt.size; nf=2*L+1; out=np.zeros((nf,N),complex)
    for t in range(N):
        for k,tau in enumerate(range(-L,L+1)):
            if 0<=t+tau<N and 0<=t-tau<N: out[k,t]=zt[t+tau]*np.conj(zt[t-tau])
    return np.abs(np.fft.fftshift(np.fft.fft(out,axis=0),axes=0))**2/N

def hough_dense(Wsum,n_f0,n_beta,L,N):
    f0=np.linspace(0,0.5,n_f0); beta=np.linspace(-0.5,0.5,n_beta)/N
    tax=np.arange(N); WHT=np.zeros((n_f0,n_beta))
    for i,f0v in enumerate(f0):
        for j,b in enumerate(beta):
            fl=f0v+b*tax; fi=np.clip(np.round((fl+0.5)*(2*L)).astype(int),0,2*L)
            WHT[i,j]=Wsum[fi,tax].sum()
    return WHT

def hough_sparse(Wsum,support_ts,n_f0,n_beta,L,N):
    """Integrate only over retained time columns (sparse support)."""
    f0=np.linspace(0,0.5,n_f0); beta=np.linspace(-0.5,0.5,n_beta)/N
    tcols=np.where(support_ts)[0]; WHT=np.zeros((n_f0,n_beta))
    for i,f0v in enumerate(f0):
        for j,b in enumerate(beta):
            fl=f0v+b*tcols; fi=np.clip(np.round((fl+0.5)*(2*L)).astype(int),0,2*L)
            WHT[i,j]=Wsum[fi,tcols].sum()
    return WHT

# =====================================================================
def exp_determined(T=80, N=512):
    SNRS=[-5,0,5,10,15,20]
    order=["AMUSE","SOBI","FOBI","FastICA","TF-BSS (WVD-JD)","Proposed"]
    res={s:{k:[] for k in order} for s in SNRS}
    t0=time.time()
    for s in SNRS:
        for tr in range(T):
            rng=np.random.default_rng(4000+tr)
            x,S,A=make_chirp_mixture(3,3,N,s,rng,noise_src=1)  # 2 chirps + 1 structured noise
            res[s]["AMUSE"].append(sir_complex(S,H.amuse(x,3)))
            res[s]["SOBI"].append(sir_complex(S,H.sobi(x,3)))
            res[s]["FOBI"].append(sir_complex(S,H.fobi(x,3)))
            try: res[s]["FastICA"].append(sir_complex(S,H.fastica(x,3).astype(complex)))
            except: pass
            res[s]["TF-BSS (WVD-JD)"].append(sir_complex(S,tfbss_wvdjd(x,3)))
            Sh,_,_=determined_v2(x,3); res[s]["Proposed"].append(sir_complex(S,Sh))
        print(f"[determined] SNR={s} ({time.time()-t0:.0f}s)")
    summ={m:{s:[float(np.mean(res[s][m])),float(np.std(res[s][m]))] for s in SNRS} for m in order}
    json.dump({"snrs":SNRS,"order":order,"summary":summ}, open(f"{OUT}/determined.json","w"), indent=2)
    return summ

def exp_underdet(T=80, N=512):
    SNRS=[0,5,10,15,20]
    res={"sir":{},"mixerr":{}}
    pipe=H.Pipeline(CLF,n=3)
    t0=time.time()
    for s in SNRS:
        sir=[]; me=[]
        for tr in range(T):
            rng=np.random.default_rng(6000+tr)
            x,S,A=make_chirp_mixture(2,3,N,s,rng,noise_src=1)
            try:
                Sh,Ah,info=pipe.separate_underdet(x)
                sir.append(sir_complex(S,Sh.astype(complex))); me.append(mix_err(A,Ah))
            except Exception: pass
        res["sir"][s]=[float(np.mean(sir)),float(np.std(sir))]; res["mixerr"][s]=[float(np.mean(me)),float(np.std(me))]
        print(f"[underdet] SNR={s}: SIR={np.mean(sir):.2f} mixErr={np.mean(me):.3f} ({time.time()-t0:.0f}s)")
    json.dump({"snrs":SNRS,**res}, open(f"{OUT}/underdet.json","w"), indent=2)
    return res

def exp_rf_detection(n_test=150):
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import precision_recall_fscore_support
    def gen(rng):
        nf,nb=32,32; K=rng.integers(1,4); img=rng.normal(scale=0.5,size=(nf,nb))**2; pk=[]
        for _ in range(K):
            pi,pj=rng.integers(2,nf-2),rng.integers(2,nb-2); amp=rng.uniform(2,5)
            for di in range(-1,2):
                for dj in range(-1,2): img[pi+di,pj+dj]+=amp*np.exp(-(di**2+dj**2))
            pk.append((pi,pj))
        lab=np.zeros((nf,nb),int)
        for pi,pj in pk:
            for di in range(-1,2):
                for dj in range(-1,2):
                    if 0<=pi+di<nf and 0<=pj+dj<nb: lab[pi+di,pj+dj]=1
        return img,lab
    rng=np.random.default_rng(31)
    Xte,yte=[],[]
    for _ in range(n_test):
        img,lab=gen(rng); Xte.append(np.nan_to_num(hough_features(img,win=3).reshape(-1,12))); yte.append(lab.ravel())
    Xte=np.concatenate(Xte); yte=np.concatenate(yte)
    rng2=np.random.default_rng(7); Xtr,ytr=[],[]
    for _ in range(150):
        img,lab=gen(rng2); Xtr.append(np.nan_to_num(hough_features(img,win=3).reshape(-1,12))); ytr.append(lab.ravel())
    Xtr=np.concatenate(Xtr); ytr=np.concatenate(ytr)
    out={}
    amp=Xte[:,0]; thr=np.quantile(amp,1-yte.mean()); yh=(amp>=thr).astype(int)
    out["Fixed threshold"]=list(precision_recall_fscore_support(yte,yh,average="binary",zero_division=0)[:3])
    lr=LogisticRegression(max_iter=1000,class_weight="balanced").fit(Xtr,ytr)
    yh=(lr.predict_proba(Xte)[:,1]>=0.5).astype(int)
    out["Logistic regression"]=list(precision_recall_fscore_support(yte,yh,average="binary",zero_division=0)[:3])
    yh=(CLF.predict_proba(Xte)[:,1]>=0.5).astype(int)
    out["Random forest"]=list(precision_recall_fscore_support(yte,yh,average="binary",zero_division=0)[:3])
    out["positive_rate"]=float(yte.mean())
    json.dump(out, open(f"{OUT}/rf_detection.json","w"), indent=2)
    print("[rf] ",{k:[round(x,3) for x in v] if isinstance(v,list) else round(v,4) for k,v in out.items()})
    return out

def exp_ablation(T=60,N=512,snr=10):
    """End-to-end effect of DT-SCA on/off (SIR + mean support fraction)."""
    on=[]; off=[]; sup=[]
    for tr in range(T):
        rng=np.random.default_rng(9000+tr)
        x,S,A=make_chirp_mixture(3,3,N,snr,rng,noise_src=1)
        Sh,_,supp=determined_v2(x,3,use_dtsca=True); on.append(sir_complex(S,Sh)); sup.append(supp)
        Sh2,_,_=determined_v2(x,3,use_dtsca=False); off.append(sir_complex(S,Sh2))
    out={"snr":snr,"dtsca_on_sir":[float(np.mean(on)),float(np.std(on))],
         "dtsca_off_sir":[float(np.mean(off)),float(np.std(off))],
         "mean_support":[float(np.mean(sup)),float(np.std(sup))]}
    json.dump(out, open(f"{OUT}/ablation.json","w"), indent=2)
    print("[ablation]",out); return out

def exp_closely_spaced(T=40,N=512,snr=10):
    """Two chirps with decreasing chirp-rate separation; measure SIR."""
    seps=[0.40,0.28,0.18,0.10,0.05,0.02]  # normalized beta separation (x/N)
    res={}
    for dsep in seps:
        sir=[]
        for tr in range(T):
            rng=np.random.default_rng(11000+tr); t=np.arange(N)
            b1=0.15/N; b2=(0.15+dsep)/N; ph1,ph2=rng.uniform(0,2*np.pi,2)
            s1=np.exp(1j*(2*np.pi*(0.08*t+0.5*b1*t*t)+ph1))
            s2=np.exp(1j*(2*np.pi*(0.30*t+0.5*b2*t*t)+ph2))
            s3=H.make_color_noise(N,rng)
            S=np.array([s1,s2,s3]); S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
            A=H.random_mixing(3,3,rng); xc=A@S
            sig=np.mean(np.abs(xc)**2); npw=sig/(10**(snr/10))
            x=xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
            Sh,_,_=determined_v2(x,3); sir.append(sir_complex(S,Sh))
        res[f"{dsep:.2f}"]=[float(np.mean(sir)),float(np.std(sir))]
    json.dump({"snr":snr,"sep_sir":res}, open(f"{OUT}/closely_spaced.json","w"), indent=2)
    print("[closely-spaced]",{k:round(v[0],2) for k,v in res.items()}); return res

def exp_complexity():
    """Dense vs truly-sparse Wigner-Hough integration: support fraction + runtime."""
    rows=[]
    for N in (256,512,1024,2048):
        rng=np.random.default_rng(5); x,S,A=make_chirp_mixture(3,3,N,10,rng,noise_src=1)
        z,W,ns,_=whiten_subspace(x,force_dim=3)
        f,t,X0=stft(x[0],nperseg=128,noverlap=112,return_onesided=False)
        Xf=np.zeros((3,)+X0.shape,dtype=complex); Xf[0]=X0
        for i in range(1,3): Xf[i]=stft(x[i],nperseg=128,noverlap=112,return_onesided=False)[2]
        mask=dt_sca_support(Xf,alpha1=0.05,alpha2=0.60,window=1)
        # collapse mask to retained time columns for the sparse integrator
        col=mask.any(axis=0)
        # upsample column support to signal length
        L=24; Wsum=np.zeros((2*L+1,N))
        for k in range(3): Wsum+=wvd_channel(z[k],L)
        colN=np.zeros(N,bool); idx=np.clip((np.linspace(0,len(col)-1,N)).astype(int),0,len(col)-1); colN=col[idx]
        t1=time.time(); hough_dense(Wsum,32,32,L,N); td=time.time()-t1
        t1=time.time(); hough_sparse(Wsum,colN,32,32,L,N); ts=time.time()-t1
        rows.append({"N":N,"support_frac":float(mask.mean()),"col_frac":float(colN.mean()),
                     "dense_s":td,"sparse_s":ts,"speedup":td/max(ts,1e-6)})
        print(f"[complexity] N={N}: support={mask.mean():.1%} col={colN.mean():.1%} dense={td:.3f}s sparse={ts:.3f}s speedup={td/max(ts,1e-6):.2f}x")
    json.dump(rows, open(f"{OUT}/complexity.json","w"), indent=2)
    return rows

if __name__=="__main__":
    which=sys.argv[1] if len(sys.argv)>1 else "all"
    if which in ("all","det"): exp_determined()
    if which in ("all","und"): exp_underdet()
    if which in ("all","rf"): exp_rf_detection()
    if which in ("all","abl"): exp_ablation()
    if which in ("all","cs"): exp_closely_spaced()
    if which in ("all","cx"): exp_complexity()
    print("DONE")

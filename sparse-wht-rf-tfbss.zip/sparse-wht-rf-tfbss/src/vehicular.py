"""
vehicular.py : two more realistic, vehicular-oriented stress tests.
 (A) Doppler: per-source carrier frequency offset emulating relative motion.
 (B) Non-ideal ULA array: steering-vector mixing with per-element gain/phase
     mismatch (mutual-coupling-like imperfection), instead of an idealized
     random Gaussian mixing matrix.
All numbers real. Writes results/final/vehicular.json and a figure.
"""
import os, sys, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE); sys.path.insert(0,HERE)
import harness as H
from improved import determined_v2, make_chirp_sources
OUT=os.path.join(HERE,"..","results","final")

def sir_complex(S,Sh):
    K=min(S.shape[0],Sh.shape[0]); L=min(S.shape[1],Sh.shape[1]); S=S[:K,:L]; Sh=Sh[:K,:L]
    Sn=S/(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); Hn=Sh/(np.linalg.norm(Sh,axis=1,keepdims=True)+1e-12)
    C=np.abs(Sn@Hn.conj().T); used=set(); sirs=[]
    for i in range(K):
        j=next(jj for jj in np.argsort(C[i])[::-1] if jj not in used); used.add(j)
        s=S[i]; h=Sh[j]; a=(h.conj()@s)/(h.conj()@h+1e-12); sirs.append(10*np.log10(np.sum(np.abs(s)**2)/(np.sum(np.abs(s-a*h)**2)+1e-12)))
    return float(np.mean(sirs))

def ula_steering(m, theta):
    # half-wavelength ULA steering vector
    return np.exp(1j*np.pi*np.arange(m)*np.sin(theta))

def mixing_ula(m,n,rng,mismatch=0.0):
    A=np.zeros((m,n),complex)
    thetas=rng.uniform(-np.pi/3,np.pi/3,n)
    for k in range(n):
        a=ula_steering(m,thetas[k])
        if mismatch>0:  # per-element gain/phase error (non-ideal array)
            g=1+mismatch*rng.standard_normal(m); ph=mismatch*rng.standard_normal(m)
            a=a*g*np.exp(1j*ph)
        A[:,k]=a/ (np.linalg.norm(a)+1e-12)
    return A

def mix_from_A(A,S,snr,rng):
    xc=A@S; sig=np.mean(np.abs(xc)**2); npw=sig/(10**(snr/10))
    return xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)

def apply_doppler(S,fd_norm,rng):
    N=S.shape[1]; t=np.arange(N); out=S.copy()
    for k in range(S.shape[0]):
        fd=rng.uniform(-fd_norm,fd_norm); out[k]=S[k]*np.exp(1j*2*np.pi*fd*t)
    return out

def run():
    res={"doppler":{},"array":{}}
    # (A) Doppler sweep (determined m=3,n=3, SNR=10)
    fds=[0.0,0.01,0.02,0.05,0.10]
    for fd in fds:
        pr=[]; so=[]
        for tr in range(40):
            rng=np.random.default_rng(21000+tr)
            S=make_chirp_sources(3,512,rng,noise_src=1); S=apply_doppler(S,fd,rng)
            A=H.random_mixing(3,3,rng); x=mix_from_A(A,S,10,rng)
            pr.append(sir_complex(S,determined_v2(x,3)[0])); so.append(sir_complex(S,H.sobi(x,3)))
        res["doppler"][f"{fd:.2f}"]={"Proposed":[float(np.mean(pr)),float(np.std(pr))],"SOBI":[float(np.mean(so)),float(np.std(so))]}
        print(f"[doppler] fd={fd:.2f} Proposed={np.mean(pr):.2f} SOBI={np.mean(so):.2f}")
    # (B) Non-ideal ULA array (determined m=3,n=3, SNR=10)
    for mm in [0.0,0.05,0.10,0.20,0.30]:
        pr=[]; so=[]
        for tr in range(40):
            rng=np.random.default_rng(22000+tr)
            S=make_chirp_sources(3,512,rng,noise_src=1)
            A=mixing_ula(3,3,rng,mismatch=mm); x=mix_from_A(A,S,10,rng)
            pr.append(sir_complex(S,determined_v2(x,3)[0])); so.append(sir_complex(S,H.sobi(x,3)))
        res["array"][f"{mm:.2f}"]={"Proposed":[float(np.mean(pr)),float(np.std(pr))],"SOBI":[float(np.mean(so)),float(np.std(so))]}
        print(f"[array] mismatch={mm:.2f} Proposed={np.mean(pr):.2f} SOBI={np.mean(so):.2f}")
    json.dump(res,open(f"{OUT}/vehicular.json","w"),indent=2)
    # figure
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.3,"font.family":"serif","savefig.bbox":"tight"})
    fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
    fds_=[float(k) for k in res["doppler"]]
    ax[0].errorbar(fds_,[res["doppler"][f"{f:.2f}"]["Proposed"][0] for f in fds_],
                   yerr=[res["doppler"][f"{f:.2f}"]["Proposed"][1] for f in fds_],marker="*",ms=8,lw=1.8,label="Proposed",color="#b2182b",capsize=3)
    ax[0].errorbar(fds_,[res["doppler"][f"{f:.2f}"]["SOBI"][0] for f in fds_],
                   yerr=[res["doppler"][f"{f:.2f}"]["SOBI"][1] for f in fds_],marker="s",ms=5,lw=1.2,label="SOBI",color="#2166ac",capsize=3)
    ax[0].set_xlabel(r"Max normalized Doppler $f_dT_s$"); ax[0].set_ylabel("Mean SIR (dB)"); ax[0].set_title("(a) Doppler",fontsize=8); ax[0].legend(fontsize=7)
    mms=[float(k) for k in res["array"]]
    ax[1].errorbar(mms,[res["array"][f"{m:.2f}"]["Proposed"][0] for m in mms],
                   yerr=[res["array"][f"{m:.2f}"]["Proposed"][1] for m in mms],marker="*",ms=8,lw=1.8,label="Proposed",color="#b2182b",capsize=3)
    ax[1].errorbar(mms,[res["array"][f"{m:.2f}"]["SOBI"][0] for m in mms],
                   yerr=[res["array"][f"{m:.2f}"]["SOBI"][1] for m in mms],marker="s",ms=5,lw=1.2,label="SOBI",color="#2166ac",capsize=3)
    ax[1].set_xlabel(r"ULA gain/phase mismatch $\varepsilon$"); ax[1].set_ylabel("Mean SIR (dB)"); ax[1].set_title("(b) Non-ideal ULA array",fontsize=8); ax[1].legend(fontsize=7)
    plt.tight_layout(); plt.savefig(os.path.join(HERE,"..","figures","fig_vehicular.pdf")); print("figure saved")

if __name__=="__main__": run()

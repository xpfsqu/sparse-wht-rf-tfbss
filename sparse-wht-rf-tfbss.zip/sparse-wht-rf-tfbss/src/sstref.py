"""
sstref.py — reassignment/synchrosqueezing-based refinement that removes the
STFT-resolution ceiling of plain IF-ridge masking.

Idea: estimate the instantaneous frequency (IF) to sub-bin accuracy by
time-frequency reassignment (Gaussian window + derivative window), then
demodulate the component ALONG the estimated IF curve (a curve-following,
model-free generalization of dechirp) so it maps to DC regardless of IF law,
low-pass at DC with a narrow band, and remodulate. The final filtering is
pointwise + a sharp DC low-pass, so there is no bin-quantization ceiling.
Pure numpy/scipy.
"""
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import medfilt
import algo as A

def reassigned_if(s, L=97, sigma=None):
    """Per-sample instantaneous frequency (cycles/sample, in [-0.5,0.5)) via
    frequency reassignment with a Gaussian window (hop = 1)."""
    s=np.asarray(s,dtype=complex); N=len(s)
    if sigma is None: sigma=L/6.0
    k=np.arange(L)-(L-1)/2.0
    g=np.exp(-0.5*(k/sigma)**2); g/=np.linalg.norm(g)
    gd=(-k/sigma**2)*g                                  # time-derivative of window
    sp=np.pad(s,(L//2,L//2),mode="reflect")
    freqs=np.fft.fftfreq(L)                             # cycles/sample
    nu=np.zeros(N)
    for n in range(N):
        seg=sp[n:n+L]
        Z=np.fft.fft(seg*g); Zd=np.fft.fft(seg*gd)
        r=int(np.argmax(np.abs(Z)))
        # reassigned angular freq = w - Im(Zd/Z); convert to cycles/sample
        corr=np.imag(Zd[r]/(Z[r]+1e-12))/(2*np.pi)
        nu[n]=freqs[r]-corr
    # wrap to [-0.5,0.5)
    nu=(nu+0.5)%1.0-0.5
    return nu

def sst_refine(s, L=97, bw_frac=0.010, thr=0.22, smooth=11, passes=2):
    """Reassignment-based refinement. Estimate the IF by reassignment, demodulate
    along it to DC, low-pass with a narrow band, remodulate. Iterating removes the
    slow phase drift from residual IF error, raising the high-SNR ceiling."""
    s=np.asarray(s,dtype=complex); N=len(s); Phi_tot=np.zeros(N); y=s.copy()
    for _ in range(passes):
        nu=reassigned_if(y,L=L); ks=smooth|1
        if N>=ks>=3: nu=medfilt(nu,kernel_size=ks)
        Phi=2*np.pi*np.cumsum(nu); Phi_tot=Phi_tot+Phi; y=y*np.exp(-1j*Phi)
    Y=np.fft.fft(y); nb=max(2,int(bw_frac*N)); mask=np.zeros(N,bool); mask[:nb]=True; mask[-nb:]=True
    if np.sum(np.abs(Y[mask])**2)/(np.sum(np.abs(Y)**2)+1e-12)<thr: return s
    return np.fft.ifft(Y*mask)*np.exp(1j*Phi_tot)

def refine_sst_all(Sh):
    return np.array([sst_refine(Sh[i].astype(complex)) for i in range(Sh.shape[0])])

if __name__=="__main__":
    # ---- validate IF estimate on known laws ----
    N=512; t=np.arange(N)
    f0,b=0.10,0.25/N; chirp=np.exp(1j*2*np.pi*(f0*t+0.5*b*t*t)); true_if=f0+b*t
    est=reassigned_if(chirp); print("linear chirp IF RMSE:",round(float(np.sqrt(np.mean((est[20:-20]-true_if[20:-20])**2))),5))
    fc,dfm,fm=0.20,0.05,3.0/N; phase=2*np.pi*(fc*t+(dfm/(2*np.pi*fm))*np.sin(2*np.pi*fm*t))
    sfm=np.exp(1j*phase); true_if2=fc+dfm*np.cos(2*np.pi*fm*t)
    est2=reassigned_if(sfm); print("sin-FM IF RMSE:",round(float(np.sqrt(np.mean((est2[20:-20]-true_if2[20:-20])**2))),5))

    # ---- compare on nonlinear FM mixtures: ridge vs SST, high SNR ----
    from generalize import make_sinfm_mixture, tf_ridge_refine
    print("\nNonlinear-FM FM-only SIR: SOBI / Ridge(STFT) / SST(reassign)")
    for snr in (0,10,15,20,25):
        so=[];rg=[];ss=[]
        for tr in range(25):
            rng=np.random.default_rng(8000+tr); x,S,Am=make_sinfm_mixture(3,3,512,snr,rng,noise_src=1)
            jj=A.determined_v2(x,3)[0].astype(complex)
            so.append(A.sir_complex(S[:2],A.sobi(x,3)[:2]))
            rg.append(A.sir_complex(S[:2],np.array([tf_ridge_refine(jj[i]) for i in range(3)])[:2]))
            ss.append(A.sir_complex(S[:2],refine_sst_all(jj)[:2]))
        print(f"  SNR={snr:2d}: SOBI={np.mean(so):5.2f}  Ridge={np.mean(rg):5.2f}  SST={np.mean(ss):5.2f}")

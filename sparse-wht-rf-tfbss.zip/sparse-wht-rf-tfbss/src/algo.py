"""
algo.py — consolidated honest pipeline for the TSP version.
Rebuilds (after a container reset) the baselines, mixtures, metrics and the
improved determined branch (SSP-clustered joint diagonalisation). Depends on
proposed.py (original companion building blocks) in the same directory.
"""
from __future__ import annotations
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import stft
from scipy.linalg import eigh, pinv
from sklearn.cluster import KMeans
from proposed import whiten_subspace, dt_sca_support, joint_diagonalise, SparseWhtRfTfbss

# ---------------- metrics ----------------
def sir_complex(S,Sh):
    """Permutation/complex-scale-invariant SIR (dB), mean over sources."""
    K=min(S.shape[0],Sh.shape[0]); L=min(S.shape[1],Sh.shape[1]); S=S[:K,:L]; Sh=Sh[:K,:L]
    Sn=S/(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); Hn=Sh/(np.linalg.norm(Sh,axis=1,keepdims=True)+1e-12)
    C=np.abs(Sn@Hn.conj().T); used=set(); sirs=[]
    for i in range(K):
        j=next(jj for jj in np.argsort(C[i])[::-1] if jj not in used); used.add(j)
        s=S[i]; h=Sh[j]; a=(h.conj()@s)/(h.conj()@h+1e-12)
        sirs.append(10*np.log10(np.sum(np.abs(s)**2)/(np.sum(np.abs(s-a*h)**2)+1e-12)))
    return float(np.mean(sirs))

def mix_err(A,Ah):
    m=min(A.shape[0],Ah.shape[0]); n=min(A.shape[1],Ah.shape[1]); A=A[:m,:n]; Ah=Ah[:m,:n]
    A=A/(np.linalg.norm(A,axis=0,keepdims=True)+1e-12); Ah=Ah/(np.linalg.norm(Ah,axis=0,keepdims=True)+1e-12)
    C=np.abs(A.conj().T@Ah); used=set(); e=[]
    for i in range(n):
        j=next(jj for jj in np.argsort(C[i])[::-1] if jj not in used); used.add(j); e.append(1-C[i,j])
    return float(np.mean(e))

def mutual_coherence(A):
    An=A/(np.linalg.norm(A,axis=0,keepdims=True)+1e-12)
    G=np.abs(An.conj().T@An); np.fill_diagonal(G,0.0); return float(G.max())

# ---------------- sources / mixtures ----------------
def make_color_noise(N,rng):
    n=rng.standard_normal(N)+1j*rng.standard_normal(N); return np.convolve(n,np.ones(5)/5.0,mode="same")
def make_speech_like(N,rng):
    base=rng.standard_normal(N)+1j*rng.standard_normal(N); env=0.5+0.5*np.sin(2*np.pi*0.003*np.arange(N)); return env*base
def make_chirp_sources(n,N,rng,noise_src=0):
    t=np.arange(N); f0s=[0.05,0.15,0.28,0.40]; betas=[0.15/N,0.28/N,0.42/N,0.55/N]; src=[]
    for i in range(n-noise_src):
        ph=rng.uniform(0,2*np.pi); src.append(np.exp(1j*(2*np.pi*(f0s[i%4]*t+0.5*betas[i%4]*t*t)+ph)))
    for j in range(noise_src):
        src.append(make_color_noise(N,rng) if j%2==0 else make_speech_like(N,rng))
    S=np.array(src,dtype=complex); S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N); return S
def random_mixing(m,n,rng):
    A=rng.standard_normal((m,n))+1j*rng.standard_normal((m,n)); return A/(np.linalg.norm(A,axis=0,keepdims=True)+1e-12)
def make_chirp_mixture(m,n,N,snr,rng,noise_src=0,A=None):
    S=make_chirp_sources(n,N,rng,noise_src=noise_src)
    if A is None: A=random_mixing(m,n,rng)
    xc=A@S; sig=np.mean(np.abs(xc)**2); npw=sig/(10**(snr/10))
    nz=(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
    return xc+nz,S,A

# ---------------- classical baselines ----------------
def _whiten(x):
    m,N=x.shape; R=(x@x.conj().T)/N; d,E=eigh(R); idx=np.argsort(d)[::-1]; d=np.maximum(d[idx].real,1e-12); E=E[:,idx]
    W=np.diag(1/np.sqrt(d))@E.conj().T; return W@x,W
def _lagcov(z,tau):
    N=z.shape[1]
    if tau==0: return (z@z.conj().T)/N
    R=(z[:,tau:]@z[:,:N-tau].conj().T)/(N-tau); return 0.5*(R+R.conj().T)
def amuse(x,n,tau=1):
    z,W=_whiten(x); d,U=eigh(_lagcov(z,tau)); return (U.conj().T@z)[:n]
def sobi(x,n,taus=(1,2,3,5,8,13,21)):
    z,W=_whiten(x); V=joint_diagonalise([_lagcov(z,t) for t in taus],max_iter=60); return (V.conj().T@z)[:n]
def fobi(x,n):
    z,W=_whiten(x); nr=np.linalg.norm(z,axis=0); Rw=(z*(nr**2))@z.conj().T/z.shape[1]; d,U=eigh(Rw); return (U.conj().T@z)[:n]
def fastica(x,n,seed=0):
    from sklearn.decomposition import FastICA
    return FastICA(n_components=n,random_state=seed,max_iter=800,whiten="unit-variance",tol=1e-3).fit_transform(x.real.T).T

# ---------------- improved determined branch (SSP-clustered JD) ----------------
def _mc_stft(x,nperseg,noverlap):
    m=x.shape[0]; X0=stft(x[0],nperseg=nperseg,noverlap=noverlap,return_onesided=False)[2]
    X=np.zeros((m,)+X0.shape,dtype=complex); X[0]=X0
    for i in range(1,m): X[i]=stft(x[i],nperseg=nperseg,noverlap=noverlap,return_onesided=False)[2]
    return X
def determined_v2(x,n,nperseg=128,noverlap=112,alpha1=0.05,alpha2=0.60,per_cluster=12,use_dtsca=True):
    m,N=x.shape; z,W,n_s,_=whiten_subspace(x,force_dim=min(m,n)); X=_mc_stft(x,nperseg,noverlap)
    if use_dtsca: mask=dt_sca_support(X,alpha1=alpha1,alpha2=alpha2,window=1)
    else:
        energy=np.sum(np.abs(X)**2,axis=0); mask=energy>=alpha1*energy.max()
    idx=np.argwhere(mask); Zc=[]; ener=[]
    for (fi,ti) in idx:
        v=W@X[:,fi,ti]; nr=np.linalg.norm(v)
        if nr>1e-9: Zc.append(v/nr); ener.append(nr)
    if len(Zc)<n:
        M=[(z@z.conj().T)/N]; V=joint_diagonalise(M); A=pinv(W)@V; S=pinv(A)@x
        if S.shape[0]<n: S=np.vstack([S,np.zeros((n-S.shape[0],N),complex)])
        return S[:n],A,1.0
    Zc=np.array(Zc); ener=np.array(ener)
    Za=Zc*np.exp(-1j*np.angle(Zc[:,[0]]+1e-12)); emb=np.concatenate([Za.real,Za.imag],1)
    emb/=(np.linalg.norm(emb,axis=1,keepdims=True)+1e-12)
    lab=KMeans(n_clusters=n,n_init=6,random_state=0).fit(emb).labels_
    M=[]
    for c in range(n):
        cid=np.where(lab==c)[0]
        if len(cid)==0: continue
        for k in cid[np.argsort(ener[cid])[::-1][:per_cluster]]:
            v=Zc[k]*ener[k]; M.append(np.outer(v,v.conj()))
    if len(M)<2: M=[(z@z.conj().T)/N]
    V=joint_diagonalise(M,max_iter=80); A=pinv(W)@V; S=pinv(A)@x
    if S.shape[0]<n: S=np.vstack([S,np.zeros((n-S.shape[0],N),complex)])
    return S[:n],A,float(mask.mean())

def separate_underdet(x,n,clf,alpha1=0.03,alpha2=0.55,nperseg=128,noverlap=96,L=32,lam=0.1):
    algo=SparseWhtRfTfbss(n_sources=n,alpha1=alpha1,alpha2=alpha2,nperseg=nperseg,noverlap=noverlap,L_wvd=L,lam=lam)
    algo._clf=clf; return algo.separate(x)

# ---------------- chirp-model matched refinement (beats SOBI on chirp sources) ----------------
def _concentration(s, n_beta=96):
    """Best dechirp rate beta and the resulting tone concentration ratio."""
    N=len(s); t=np.arange(N); bg=np.linspace(-0.6,0.6,n_beta)/N; best=(-1.0,0.0)
    for b in bg:
        F=np.abs(np.fft.fft(s*np.exp(-1j*np.pi*b*t*t)))
        pk=F.max()
        if pk>best[0]: best=(pk,b)
    b=best[1]; F=np.abs(np.fft.fft(s*np.exp(-1j*np.pi*b*t*t)))
    return float(F.max()/(np.linalg.norm(F)+1e-12)), b

def refine_chirp(s, frac=0.06, thr=0.25):
    """If s is a concentrated chirp, strip off-ridge interference by
    dechirp -> narrowband filter around the tone -> rechirp. Leave non-chirps."""
    s=np.asarray(s,dtype=complex); N=len(s); t=np.arange(N)
    cr,b=_concentration(s)
    if cr<thr: return s
    dd=s*np.exp(-1j*np.pi*b*t*t); F=np.fft.fft(dd); k=int(np.argmax(np.abs(F)))
    nb=max(2,int(frac*N)); mask=np.zeros(N,bool); mask[(k+np.arange(-nb,nb+1))%N]=True
    return np.fft.ifft(F*mask)*np.exp(1j*np.pi*b*t*t)

def refine_sources(Sh):
    return np.array([refine_chirp(Sh[i]) for i in range(Sh.shape[0])])

def determined_refined(x,n,**kw):
    """Proposed determined branch: SSP-clustered JD + chirp-matched refinement."""
    S,Amat,sup=determined_v2(x,n,**kw)
    return refine_sources(S.astype(complex)),Amat,sup

# ---------------- general IF-ridge refinement (arbitrary non-stationary) --------
from scipy.signal import stft as _stft, istft as _istft, medfilt as _medfilt
def tf_ridge_refine(s, nperseg=64, noverlap=48, bw=2, thr=0.30, smooth=7):
    """Generalizes dechirp refinement to any single-IF non-stationary component:
    follow the instantaneous-frequency ridge in the STFT, keep a narrow band
    around the smoothed ridge, invert. Dechirp is the straight-ridge special case."""
    s=np.asarray(s,dtype=complex); N=len(s)
    f,t,Z=_stft(s,nperseg=nperseg,noverlap=noverlap,return_onesided=False)
    mag=np.abs(Z); nf,nt=Z.shape
    if nt<3: return s
    ridge=np.argmax(mag,axis=0).astype(float)
    ks=smooth if smooth%2==1 else smooth+1
    if nt>=ks>=3: ridge=_medfilt(ridge,kernel_size=ks)
    ridge=ridge.astype(int)
    band=np.zeros_like(mag,bool)
    for j in range(nt): band[(ridge[j]+np.arange(-bw,bw+1))%nf,j]=True
    if np.sum(mag[band]**2)/(np.sum(mag**2)+1e-12)<thr: return s
    _,sr=_istft(np.where(band,Z,0.0),nperseg=nperseg,noverlap=noverlap,input_onesided=False)
    sr=np.asarray(sr)
    if len(sr)<N: sr=np.pad(sr,(0,N-len(sr)))
    return sr[:N]

def refine_ridge_all(Sh):
    return np.array([tf_ridge_refine(Sh[i].astype(complex)) for i in range(Sh.shape[0])])

def determined_refined_general(x,n,**kw):
    """Determined branch + general IF-ridge refinement (for non-chirp components)."""
    S,Amat,sup=determined_v2(x,n,**kw)
    return refine_ridge_all(S.astype(complex)),Amat,sup

if __name__=="__main__":
    rng=np.random.default_rng(0); x,S,A=make_chirp_mixture(3,3,512,10,rng,noise_src=1)
    Sh,Ah,sup=determined_v2(x,3); print("determined SIR",round(sir_complex(S,Sh),2),"support",round(sup,3))
    print("SOBI SIR",round(sir_complex(S,sobi(x,3)),2))

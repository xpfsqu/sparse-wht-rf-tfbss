"""
proposed.py
===========
Reference implementation of the Sparse-WHT/RF time-frequency blind source
separation algorithm described in the manuscript.

This module implements Algorithm 1 of the paper, including:

    * MDL-based subspace whitening                  (eqs. 5-8)
    * Dual-threshold sparse component analysis      (eq. 10 = DT-SCA)
    * Sparse Wigner-Hough integration               (eq. 11)
    * Random-forest peak detector in Hough space    (Section IV-B)
    * Determined-mode joint diagonalization branch  (Algorithm 1, lines 9-12)
    * Underdetermined-mode SSP clustering + FISTA   (Algorithm 1, lines 13-21)
      ell_1 source recovery branch                  (eqs. 12-13)

Comment cross-references such as "[Step 5]" point to Algorithm 1 line numbers
in the revised manuscript.

The implementation is deliberately self-contained: it depends on numpy,
scipy, and scikit-learn only. It is faithful to the math of the paper but
favours clarity over micro-optimisation. The dominant cost remains the
sparse WHT integration, in agreement with the complexity analysis of
Section V-B.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.signal import stft, istft
from scipy.linalg import eigh, pinv
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans


# =====================================================================
# Subspace whitening (eqs. 5-8)
# =====================================================================
def _mdl_order(eigvals: np.ndarray, N: int) -> int:
    """Minimum-description-length selection of signal-subspace dim (eq. 6)."""
    eigvals = np.sort(eigvals)[::-1]
    m = len(eigvals)
    best_n, best_score = 1, np.inf
    for p in range(1, m):
        noise = eigvals[p:]
        if np.any(noise <= 0):
            continue
        gm = np.exp(np.mean(np.log(noise)))
        am = float(np.mean(noise))
        rho = gm / am if am > 0 else 1.0
        score = -N * (m - p) * np.log(max(rho, 1e-12)) + 0.5 * p * (2 * m - p) * np.log(N)
        if score < best_score:
            best_score, best_n = score, p
    return best_n


def whiten_subspace(x: np.ndarray, force_dim: Optional[int] = None):
    """Subspace whitening via eigendecomposition (eqs. 5, 7-8).

    Parameters
    ----------
    x        : (m, N) complex observations.
    force_dim: if given, override MDL with this signal-subspace dim.

    Returns
    -------
    z        : (n_s, N) whitened observations.
    W        : (n_s, m) whitening matrix.
    n_s      : signal-subspace dimension.
    sigma2   : estimated noise variance.
    """
    m, N = x.shape
    Rxx = (x @ x.conj().T) / N
    eigvals, eigvecs = eigh(Rxx)
    idx = np.argsort(eigvals)[::-1]
    eigvals = np.real(eigvals[idx])
    eigvecs = eigvecs[:, idx]

    n_s = force_dim if force_dim is not None else _mdl_order(eigvals, N)
    n_s = max(1, min(m, n_s))

    Lambda_s = eigvals[:n_s]
    V_s = eigvecs[:, :n_s]
    sigma2 = float(np.mean(eigvals[n_s:])) if n_s < m else 0.0

    scaling = 1.0 / np.sqrt(np.maximum(Lambda_s - sigma2, 1e-12))
    W = (V_s * scaling).conj().T          # (n_s, m)
    z = W @ x
    return z, W, n_s, sigma2


# =====================================================================
# DT-SCA single-source-point detection (eq. 10)
# =====================================================================
def dt_sca_support(
    X: np.ndarray,
    alpha1: float = 0.03,
    alpha2: float = 0.70,
    window: int = 3,
) -> np.ndarray:
    """Dual-threshold SCA: identify single-source TF points (eq. 10).

    Parameters
    ----------
    X      : (m, n_freq, n_time) multi-channel STFT.
    alpha1 : energy floor as a fraction of the peak energy.
    alpha2 : single-source coherence-ratio threshold in [0, 1].
    window : half-width of the spatial-covariance smoothing window.

    Returns
    -------
    mask   : (n_freq, n_time) boolean mask of accepted TF points.
    """
    m, nf, nt = X.shape

    # Energy criterion (alpha1)
    energy = np.sum(np.abs(X) ** 2, axis=0)
    energy_norm = energy / (energy.max() + 1e-12)
    energy_mask = energy_norm >= alpha1

    # Smoothed spatial covariance at each TF point: average over (2w+1)x(2w+1)
    # window. Top eigenvalue ratio is the single-source coherence proxy.
    coh = np.zeros((nf, nt))
    # Vectorised by precomputing v v^H for each TF point then mean-pooling
    VVh = np.einsum("ift,jft->ijft", X, X.conj())   # (m, m, nf, nt)
    pad = window
    VVh_pad = np.pad(VVh, ((0, 0), (0, 0), (pad, pad), (pad, pad)), mode="edge")
    for i in range(-window, window + 1):
        for j in range(-window, window + 1):
            VVh_smooth = VVh_pad[:, :, pad + i: pad + i + nf, pad + j: pad + j + nt]
            if (i, j) == (-window, -window):
                acc = VVh_smooth.copy()
            else:
                acc += VVh_smooth
    acc /= (2 * window + 1) ** 2

    # Top eigenvalue ratio per TF point
    for fi in range(nf):
        for ti in range(nt):
            C = acc[:, :, fi, ti]
            ev = np.linalg.eigvalsh(C + 1e-12 * np.eye(m))
            top = ev[-1]
            tot = ev.sum()
            coh[fi, ti] = top / (tot + 1e-12)
    coh_mask = coh >= alpha2

    return energy_mask & coh_mask


# =====================================================================
# Sparse Wigner-Hough integral (eq. 11)
# =====================================================================
def _wvd_pseudo(z_t: np.ndarray, L: int = 32) -> np.ndarray:
    """Pseudo-Wigner-Ville distribution of a single-channel signal.

    Computes W(t, f) = sum_{tau=-L}^{L} z(t+tau) z*(t-tau) exp(-j 4 pi f tau)
    on a uniform f grid of size 2L+1.
    """
    N = z_t.size
    nf = 2 * L + 1
    out = np.zeros((nf, N), dtype=complex)
    for t in range(N):
        for k, tau in enumerate(range(-L, L + 1)):
            if 0 <= t + tau < N and 0 <= t - tau < N:
                out[k, t] = z_t[t + tau] * np.conj(z_t[t - tau])
    # FFT along tau to obtain f axis
    out = np.fft.fftshift(np.fft.fft(out, axis=0), axes=0)
    return np.abs(out) ** 2 / N


def sparse_wht_grid(
    z: np.ndarray,
    mask: np.ndarray,
    n_f0: int = 64,
    n_beta: int = 64,
    L: int = 32,
) -> np.ndarray:
    """Sparse Wigner-Hough integral over single-source TF support (eq. 11).

    Parameters
    ----------
    z      : (n_s, N) whitened observations (we integrate the trace-WVD).
    mask   : (nf, nt) boolean DT-SCA mask, downsampled or upsampled to match
             the WVD grid produced by `_wvd_pseudo`.
    n_f0   : number of initial-frequency grid points.
    n_beta : number of chirp-rate grid points.
    L      : half-width of the WVD lag kernel.

    Returns
    -------
    WHT    : (n_f0, n_beta) sparse Wigner-Hough magnitude map.
    f0_axis, beta_axis
    """
    n_s, N = z.shape
    # Sum WVDs over channels = trace of the spatial WVD
    W_sum = np.zeros((2 * L + 1, N))
    for k in range(n_s):
        W_sum += _wvd_pseudo(z[k], L)

    # Resample the DT-SCA mask onto the WVD grid
    nf_mask, nt_mask = mask.shape
    fi_idx = np.clip(
        np.linspace(0, nf_mask - 1, 2 * L + 1).astype(int), 0, nf_mask - 1
    )
    ti_idx = np.clip(np.linspace(0, nt_mask - 1, N).astype(int), 0, nt_mask - 1)
    mask_resampled = mask[np.ix_(fi_idx, ti_idx)]

    # Apply the DT-SCA mask: zero out non-SSP TF points before integration
    W_sum *= mask_resampled.astype(float)

    # Hough integration along candidate lines f = f0 + beta * t
    f0_axis = np.linspace(0.0, 0.5, n_f0)         # normalised frequency
    beta_axis = np.linspace(-0.5, 0.5, n_beta) / N
    WHT = np.zeros((n_f0, n_beta))
    f_axis = np.linspace(-0.5, 0.5, 2 * L + 1)
    t_axis = np.arange(N)

    for i, f0 in enumerate(f0_axis):
        for j, b in enumerate(beta_axis):
            f_line = f0 + b * t_axis
            f_idx = np.clip(
                np.round((f_line + 0.5) * (2 * L)).astype(int), 0, 2 * L
            )
            WHT[i, j] = W_sum[f_idx, t_axis].sum()

    return WHT, f0_axis, beta_axis


# =====================================================================
# Random-forest peak detector (Section IV-B)
# =====================================================================
def hough_features(WHT: np.ndarray, win: int = 5) -> np.ndarray:
    """Per-pixel feature vector phi in R^12 (revised Feature 1: local normaliser).

    Returns a (n_f0, n_beta, 12) feature tensor.
    """
    A = np.abs(WHT)
    nf, nb = A.shape
    pad = win
    A_pad = np.pad(A, pad, mode="edge")

    feats = np.zeros((nf, nb, 12))
    h = win
    for i in range(nf):
        for j in range(nb):
            local = A_pad[i: i + 2 * h + 1, j: j + 2 * h + 1]
            local_med = np.median(local) + 1e-12
            # 1. local-median-normalised amplitude (revision per reviewer)
            feats[i, j, 0] = A[i, j] / local_med
            # 2-3. local skewness and kurtosis
            l = local.ravel()
            mu = l.mean()
            sd = l.std() + 1e-12
            feats[i, j, 1] = float(np.mean(((l - mu) / sd) ** 3))
            feats[i, j, 2] = float(np.mean(((l - mu) / sd) ** 4) - 3.0)
            # 4. local l2 energy ratio
            feats[i, j, 3] = (A[i, j] ** 2) / (np.sum(local ** 2) + 1e-12)
            # 5-6. polar coords proxies
            feats[i, j, 4] = i
            feats[i, j, 5] = j
            # 7-8. Hessian eigenvalue ratio + entropy
            if 1 <= i < nf - 1 and 1 <= j < nb - 1:
                Hxx = A[i + 1, j] - 2 * A[i, j] + A[i - 1, j]
                Hyy = A[i, j + 1] - 2 * A[i, j] + A[i, j - 1]
                Hxy = 0.25 * (A[i + 1, j + 1] - A[i + 1, j - 1]
                              - A[i - 1, j + 1] + A[i - 1, j - 1])
                Hess = np.array([[Hxx, Hxy], [Hxy, Hyy]])
                ev = np.linalg.eigvalsh(Hess)
                feats[i, j, 6] = ev[0] / (ev[1] + 1e-12)
                feats[i, j, 7] = -float(ev[0] * np.log(abs(ev[0]) + 1e-12))
            # 9-10. matched-filter correlation with isotropic peak template
            template = np.exp(-((np.arange(-h, h + 1) ** 2)[:, None]
                                + (np.arange(-h, h + 1) ** 2)[None, :]) / (2.0 * 1.5 ** 2))
            template /= template.sum()
            feats[i, j, 8] = float(np.sum(local * template))
            feats[i, j, 9] = float(np.max(local) - np.min(local))
            # 11-12. relative rank features
            feats[i, j, 10] = (A[i, j] - mu) / sd
            feats[i, j, 11] = (A[i, j] > local.mean()).astype(float)
    return feats


def train_rf_detector(seed: int = 0, n_train_imgs: int = 80, verbose: bool = False):
    """Train an RF classifier on synthetic Hough images.

    Generates random multi-LFM Wigner-Hough patterns with known peak locations
    and labels pixels within radius 1 of a true peak as positive. Returns the
    fitted classifier and the in-sample positive-rate diagnostics.
    """
    rng = np.random.default_rng(seed)
    X_train, y_train = [], []

    nf, nb = 32, 32                         # smaller grid for fast training
    for k in range(n_train_imgs):
        K = rng.integers(1, 4)
        img = rng.normal(scale=0.5, size=(nf, nb)) ** 2
        peaks = []
        for _ in range(K):
            pi, pj = rng.integers(2, nf - 2), rng.integers(2, nb - 2)
            amp = rng.uniform(2.0, 5.0)
            for di in range(-1, 2):
                for dj in range(-1, 2):
                    img[pi + di, pj + dj] += amp * np.exp(-(di ** 2 + dj ** 2))
            peaks.append((pi, pj))

        feats = hough_features(img, win=3)
        labels = np.zeros((nf, nb), dtype=int)
        for pi, pj in peaks:
            for di in range(-1, 2):
                for dj in range(-1, 2):
                    if 0 <= pi + di < nf and 0 <= pj + dj < nb:
                        labels[pi + di, pj + dj] = 1
        X_train.append(feats.reshape(-1, feats.shape[-1]))
        y_train.append(labels.ravel())

    X_train = np.concatenate(X_train, axis=0)
    y_train = np.concatenate(y_train, axis=0)
    # Replace NaNs/infs that can arise from edge pixels
    X_train = np.nan_to_num(X_train, nan=0.0, posinf=1e3, neginf=-1e3)

    clf = RandomForestClassifier(
        n_estimators=120, max_depth=10, class_weight="balanced",
        random_state=seed, n_jobs=-1,
    )
    clf.fit(X_train, y_train)
    if verbose:
        print(f"  RF: trained on {len(y_train)} pixels, "
              f"positive rate {y_train.mean():.3f}")
    return clf


def rf_detect_peaks(WHT: np.ndarray, clf, threshold: float = 0.5):
    """Apply trained RF, then NMS to return list of (i,j) peak coordinates."""
    feats = hough_features(WHT, win=3)
    feats = np.nan_to_num(feats, nan=0.0, posinf=1e3, neginf=-1e3)
    flat = feats.reshape(-1, feats.shape[-1])
    p = clf.predict_proba(flat)[:, 1].reshape(WHT.shape)

    # Non-maximum suppression in a 3x3 neighbourhood
    nf, nb = WHT.shape
    peaks = []
    for i in range(1, nf - 1):
        for j in range(1, nb - 1):
            if p[i, j] < threshold:
                continue
            if p[i, j] >= p[i - 1:i + 2, j - 1:j + 2].max() - 1e-12:
                peaks.append((i, j, float(p[i, j])))
    return peaks, p


# =====================================================================
# Joint diagonalization (Cardoso-style Jacobi sweeps, simplified)
# =====================================================================
def joint_diagonalise(M_list, max_iter: int = 50, tol: float = 1e-6):
    """Approximate joint diagonalisation of a set of Hermitian matrices.

    Uses the classic Jacobi-rotation algorithm of Cardoso and Souloumiac (1996),
    restricted to the real-orthogonal special case after stacking the matrices
    by their real and imaginary parts. Adequate for the demo; production code
    should use the FAJDC routine of Yeredor (2002) or the algorithm of
    Fadaili et al. (2007).
    """
    n = M_list[0].shape[0]
    A = np.stack(M_list, axis=0)  # (K, n, n) complex
    V = np.eye(n, dtype=complex)

    for sweep in range(max_iter):
        off = 0.0
        for p in range(n - 1):
            for q in range(p + 1, n):
                g = np.array([
                    A[:, p, p] - A[:, q, q],
                    A[:, p, q] + A[:, q, p],
                    1j * (A[:, q, p] - A[:, p, q]),
                ])
                G = np.real(g @ g.conj().T)
                ev, ee = np.linalg.eigh(G)
                v = ee[:, -1]
                if v[0] < 0:
                    v = -v
                c = np.sqrt(0.5 * (1 + v[0]))
                s = 0.5 * (v[1] - 1j * v[2]) / max(c, 1e-12)
                if abs(s) < 1e-10:
                    continue
                R = np.eye(n, dtype=complex)
                R[p, p], R[q, q] = c, c
                R[p, q], R[q, p] = -s.conj(), s
                A = np.einsum("ij,kjl->kil", R.conj().T, A)
                A = np.einsum("kij,jl->kil", A, R)
                V = V @ R
                off += abs(s) ** 2
        if off < tol:
            break
    return V


# =====================================================================
# Underdetermined branch: SSP clustering + FISTA (eqs. 12-13)
# =====================================================================
def spherical_kmeans(unit_vecs: np.ndarray, n_clusters: int, seed: int = 0):
    """Spherical k-means on the unit hypersphere via cosine distance.

    Parameters
    ----------
    unit_vecs : (N_points, m) array of unit-norm complex vectors.
    n_clusters: number of clusters (= n, number of sources).

    Returns
    -------
    centroids : (n_clusters, m) unit-norm cluster centres.
    labels    : (N_points,) cluster assignments.
    """
    # Stack real and imaginary parts to do clustering in real space
    real_pts = np.concatenate([unit_vecs.real, unit_vecs.imag], axis=1)
    real_pts /= (np.linalg.norm(real_pts, axis=1, keepdims=True) + 1e-12)
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
    labels = km.fit_predict(real_pts)
    m = unit_vecs.shape[1]
    centroids_real = km.cluster_centers_[:, :m]
    centroids_imag = km.cluster_centers_[:, m:]
    centroids = centroids_real + 1j * centroids_imag
    centroids /= (np.linalg.norm(centroids, axis=1, keepdims=True) + 1e-12)
    return centroids, labels


def fista_l1(A: np.ndarray, b: np.ndarray, lam: float,
             n_iter: int = 80, s_init: Optional[np.ndarray] = None):
    """FISTA solver for arg min ||A s - b||^2 + lam ||s||_1 (eq. 13)."""
    n = A.shape[1]
    s = np.zeros(n, dtype=complex) if s_init is None else s_init.copy()
    s_old, t_old = s.copy(), 1.0
    y = s.copy()
    # Lipschitz constant = 2 * sigma_max(A)^2
    L = 2.0 * float(np.linalg.svd(A, compute_uv=False)[0] ** 2) + 1e-9
    for _ in range(n_iter):
        grad = 2.0 * A.conj().T @ (A @ y - b)
        z = y - grad / L
        # Complex soft-thresholding
        mag = np.abs(z)
        shrink = np.maximum(mag - lam / L, 0.0) / (mag + 1e-12)
        s_new = z * shrink
        t_new = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * t_old ** 2))
        y = s_new + ((t_old - 1.0) / t_new) * (s_new - s_old)
        s_old, t_old = s_new, t_new
    return s_new


# =====================================================================
# Main algorithm class
# =====================================================================
@dataclass
class SparseWhtRfTfbss:
    """Sparse-WHT/RF TF-BSS algorithm (Algorithm 1).

    Parameters
    ----------
    n_sources    : target number of sources (n in the paper).
    alpha1, alpha2: DT-SCA thresholds (eq. 10).
    rf_seed      : random seed for the RF detector.
    """
    n_sources: int
    alpha1: float = 0.03
    alpha2: float = 0.60
    rf_seed: int = 0
    nperseg: int = 128
    noverlap: int = 96
    L_wvd: int = 32
    lam: float = 0.1
    _clf: object = field(default=None, init=False, repr=False)

    def _ensure_rf(self):
        if self._clf is None:
            self._clf = train_rf_detector(seed=self.rf_seed, verbose=False)

    def separate(self, x: np.ndarray, verbose: bool = False):
        """Run Algorithm 1 end-to-end.

        Parameters
        ----------
        x : (m, N) observed mixture.

        Returns
        -------
        S_hat : (n_sources, N) estimated source signals.
        A_hat : estimated mixing matrix.
        info  : dict with intermediate quantities for debugging/plots.
        """
        self._ensure_rf()
        m, N = x.shape
        n = self.n_sources

        # --- Steps 2-4: subspace whitening (eqs. 5-8) -----------------
        z, W, n_s, sigma2 = whiten_subspace(x, force_dim=min(m, n))
        if verbose:
            print(f"[1-4] whitened: m={m}, n_s={n_s}, sigma2={sigma2:.3g}")

        # --- Step 5: multi-channel STFT + DT-SCA support (eq. 10) ----
        _, _, X = stft(x[0], nperseg=self.nperseg, noverlap=self.noverlap,
                       return_onesided=False)
        X_full = np.zeros((m,) + X.shape, dtype=complex)
        for i in range(m):
            _, _, X_full[i] = stft(x[i], nperseg=self.nperseg,
                                   noverlap=self.noverlap,
                                   return_onesided=False)
        mask = dt_sca_support(X_full, alpha1=self.alpha1, alpha2=self.alpha2,
                              window=1)
        if verbose:
            print(f"[5] DT-SCA mask: {mask.sum()} / {mask.size} "
                  f"TF points retained ({mask.mean():.1%})")

        # --- Step 6: sparse Wigner-Hough (eq. 11) --------------------
        WHT, f0_ax, beta_ax = sparse_wht_grid(z, mask, n_f0=32, n_beta=32,
                                              L=self.L_wvd)
        if verbose:
            print(f"[6] Hough plane peak amplitude = {WHT.max():.3g}")

        # --- Step 7-8: RF peak detection -----------------------------
        peaks, p_map = rf_detect_peaks(WHT, self._clf, threshold=0.5)
        # Fallback: if RF rejects everything, fall back to top-K amplitude peaks
        if len(peaks) < n:
            flat = WHT.ravel()
            top_idx = np.argsort(flat)[-max(n, 4):]
            peaks = [(int(i // WHT.shape[1]), int(i % WHT.shape[1]),
                      float(flat[i] / (flat.max() + 1e-12)))
                     for i in top_idx]
        if verbose:
            print(f"[7-8] RF + NMS returned {len(peaks)} candidate peaks")

        # --- Branch on determined / underdetermined regime -----------
        if m >= n:
            # ---- Determined / overdetermined branch (lines 9-12) ----
            return self._determined_branch(z, x, W, X_full, peaks, info_extras={
                "mask": mask, "WHT": WHT, "p_map": p_map,
                "peaks": peaks, "W": W,
            })
        else:
            # ---- Underdetermined branch (lines 13-21) ---------------
            return self._underdetermined_branch(X_full, mask, info_extras={
                "mask": mask, "WHT": WHT, "p_map": p_map,
                "peaks": peaks, "W": W,
            })

    # ------------------------------------------------------------------
    def _determined_branch(self, z, x, W, X_full, peaks, info_extras):
        """Algorithm 1 lines 9-12: weighted JD of spatial TFDs."""
        m, N = x.shape
        n_s = z.shape[0]
        nf, nt = X_full.shape[1], X_full.shape[2]

        # Map each (i, j) peak in the Hough plane (size n_f0 x n_beta) to a
        # representative TF point on its chirp ridge. We sample three TF points
        # along the ridge per peak so the JD set has enough variety.
        M_list = []
        if len(peaks) == 0:
            M_list = [(z @ z.conj().T) / N]
        else:
            # Hough plane has shape inferred from info: peaks are (i, j, p)
            i_max = max(p_[0] for p_ in peaks) + 1
            j_max = max(p_[1] for p_ in peaks) + 1
            top = sorted(peaks, key=lambda p_: p_[2], reverse=True)[:8]
            for (i, j, w) in top:
                # Map Hough indices into f0 and beta, then sample three TF
                # points along the predicted line f = f0 + beta * t.
                f0_norm = i / max(1, i_max - 1)            # in [0, 1]
                beta_norm = (j / max(1, j_max - 1)) - 0.5  # in [-0.5, 0.5]
                for t_frac in (0.25, 0.5, 0.75):
                    ti = int(t_frac * nt)
                    f_line = f0_norm + beta_norm * (t_frac - 0.5)
                    fi = int(np.clip(f_line * (nf - 1), 0, nf - 1))
                    Z_loc = X_full[:, max(0, fi - 1):fi + 2,
                                   max(0, ti - 1):ti + 2]
                    D = (np.einsum("ift,jft->ij", Z_loc, Z_loc.conj())
                         / max(1, Z_loc.shape[1] * Z_loc.shape[2]))
                    D = W @ D @ W.conj().T
                    M_list.append(w * D)

        U = joint_diagonalise(M_list)
        S_partial = U.conj().T @ z   # (n_s, N)
        S_hat = np.zeros((self.n_sources, N), dtype=complex)
        S_hat[:n_s] = S_partial
        A_hat = pinv(W) @ U
        info = {"branch": "determined", **info_extras}
        return S_hat.real, A_hat, info

    # ------------------------------------------------------------------
    def _underdetermined_branch(self, X_full, mask, info_extras):
        """Algorithm 1 lines 13-21: SSP clustering + per-TF-point FISTA."""
        m, nf, nt = X_full.shape
        n = self.n_sources

        # Gather single-source spatial directions on SSP support
        idxs = np.argwhere(mask)
        unit_vecs = []
        keep_idxs = []
        for (fi, ti) in idxs:
            v = X_full[:, fi, ti]
            nrm = np.linalg.norm(v)
            if nrm > 1e-8:
                unit_vecs.append(v / nrm)
                keep_idxs.append((fi, ti))
        unit_vecs = np.array(unit_vecs)
        if len(unit_vecs) < n:
            raise RuntimeError("DT-SCA returned too few SSPs to cluster.")

        # Resolve sign ambiguity by anchoring each vector to a real-positive
        # leading component (mirrors what spherical k-means expects).
        for i in range(len(unit_vecs)):
            phase = np.angle(unit_vecs[i, 0] + 1e-12)
            unit_vecs[i] *= np.exp(-1j * phase)

        centroids, labels = spherical_kmeans(unit_vecs, n_clusters=n,
                                             seed=self.rf_seed)
        A_hat = centroids.T  # (m, n)

        # Per-TF-point l_1 recovery on the full STFT support
        S_tf = np.zeros((n, nf, nt), dtype=complex)
        s_prev = None
        for fi in range(nf):
            for ti in range(nt):
                b = X_full[:, fi, ti]
                if np.linalg.norm(b) < 1e-9:
                    continue
                s = fista_l1(A_hat, b, lam=self.lam * np.linalg.norm(b),
                             n_iter=30, s_init=s_prev)
                S_tf[:, fi, ti] = s
                s_prev = s

        # Inverse STFT to time domain
        S_hat_list = []
        for j in range(n):
            _, sj = istft(S_tf[j], nperseg=self.nperseg, noverlap=self.noverlap,
                          input_onesided=False)
            S_hat_list.append(sj.real)
        L_min = min(len(s) for s in S_hat_list)
        S_hat = np.array([s[:L_min] for s in S_hat_list], dtype=float)

        info = {"branch": "underdetermined", **info_extras,
                "centroids": centroids}
        return S_hat, A_hat, info


def WHT_shape_for_peaks(peaks):
    """Helper: infer Hough-plane width from a peak list (used internally)."""
    return max([p[0] for p in peaks]) + 1 if peaks else 1


# =====================================================================
# Evaluation utility
# =====================================================================
def sir_db(s_true: np.ndarray, s_hat: np.ndarray) -> float:
    """Per-source signal-to-interference ratio in dB after optimal
    permutation, sign, and scale alignment.

    Tolerates length mismatch between the reference and estimate by
    truncating both to their common length (arises naturally after the
    forward+inverse STFT pipeline used by the underdetermined branch).
    """
    K = min(s_true.shape[0], s_hat.shape[0])
    L = min(s_true.shape[1], s_hat.shape[1])
    s_true = np.asarray(s_true[:K, :L], dtype=float)
    s_hat = np.asarray(s_hat[:K, :L], dtype=float)
    s_true_norm = s_true / (np.linalg.norm(s_true, axis=1, keepdims=True) + 1e-12)
    s_hat_norm = s_hat / (np.linalg.norm(s_hat, axis=1, keepdims=True) + 1e-12)
    # Resolve permutation by greedy correlation matching
    C = np.abs(s_true_norm @ s_hat_norm.T)
    perm = np.argmax(C, axis=1)
    sirs = []
    for i, j in enumerate(perm):
        s = s_true[i]
        h = s_hat[j]
        if np.dot(h, h) < 1e-12:
            continue
        alpha = np.dot(h, s) / np.dot(h, h)
        residual = s - alpha * h
        sir = 10 * np.log10(np.sum(s ** 2) / (np.sum(residual ** 2) + 1e-12))
        sirs.append(float(sir))
    return float(np.mean(sirs)) if sirs else float("-inf")

"""
harness.py
==========
Honest experiment harness for the Sparse-WHT/RF TF-BSS manuscript
(retargeted to IEEE TVT). Builds on the reference implementation in
pkg/src/proposed.py. Every number this file prints is produced by a real
run; nothing is hand-entered.

Design decisions for a fair, reproducible comparison:
  * The random forest is trained ONCE and reused across all trials.
  * Classical baselines (AMUSE, SOBI, FOBI, FastICA) are implemented with
    standard textbook estimators, operating on the same complex mixtures.
  * Two intermediate methods double as ablations:
        TF-BSS (WVD-JD)      = joint diagonalisation of spatial WVD matrices
                               selected by a simple energy rule (no RF, dense).
        WHT-TFBSS (fixed thr)= sparse WHT + fixed-amplitude peak threshold
                               (the Guo-Zeng-style prior art; RF removed).
  * Mixing matrices are drawn from a RANDOM complex ensemble each trial,
    so reported means reflect many mixing conditions (not one fixed A).
"""
from __future__ import annotations
import os, sys, time, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from proposed import (                       # noqa: E402
    whiten_subspace, dt_sca_support, sparse_wht_grid, hough_features,
    train_rf_detector, rf_detect_peaks, joint_diagonalise, spherical_kmeans,
    fista_l1, sir_db, SparseWhtRfTfbss,
)
from scipy.signal import stft, istft         # noqa: E402
from scipy.linalg import eigh, pinv          # noqa: E402

RNG_GLOBAL = np.random.default_rng(12345)

# =====================================================================
# Signal / mixture model  (documented in the manuscript, Sec. "Experiments")
# =====================================================================
def make_lfm(N, f0, beta, phase=0.0):
    t = np.arange(N)
    return np.exp(1j * (2 * np.pi * (f0 * t + 0.5 * beta * t * t) + phase))

def make_color_noise(N, rng):
    n = rng.standard_normal(N) + 1j * rng.standard_normal(N)
    k = np.ones(5) / 5.0
    return np.convolve(n, k, mode="same")

def make_speech_like(N, rng):
    base = rng.standard_normal(N) + 1j * rng.standard_normal(N)
    env = 0.5 + 0.5 * np.sin(2 * np.pi * 0.003 * np.arange(N))
    return env * base

def make_sources(n, N, rng, betas=None):
    """n source signals: LFM chirp(s) + structured noise sources."""
    if betas is None:
        betas = [0.20 / N]
    src = []
    f0s = [0.05, 0.18, 0.32]
    for i in range(n):
        if i < len(betas):
            src.append(make_lfm(N, f0=f0s[i % 3], beta=betas[i]))
        elif i % 2 == 0:
            src.append(make_color_noise(N, rng))
        else:
            src.append(make_speech_like(N, rng))
    S = np.array(src, dtype=complex)
    S /= (np.linalg.norm(S, axis=1, keepdims=True) + 1e-12)
    S *= np.sqrt(N)
    return S

def random_mixing(m, n, rng):
    A = rng.standard_normal((m, n)) + 1j * rng.standard_normal((m, n))
    A /= (np.linalg.norm(A, axis=0, keepdims=True) + 1e-12)
    return A

def make_mixture(m, n, N, snr_db, rng, betas=None, A=None):
    S = make_sources(n, N, rng, betas=betas)
    if A is None:
        A = random_mixing(m, n, rng)
    x_clean = A @ S
    sig = np.mean(np.abs(x_clean) ** 2)
    npow = sig / (10 ** (snr_db / 10.0))
    noise = (rng.standard_normal(x_clean.shape) + 1j * rng.standard_normal(x_clean.shape)) * np.sqrt(npow / 2)
    return x_clean + noise, S, A

# =====================================================================
# Classical baselines (textbook estimators, complex data)
# =====================================================================
def _whiten(x):
    m, N = x.shape
    R = (x @ x.conj().T) / N
    d, E = eigh(R)
    idx = np.argsort(d)[::-1]
    d = d[idx]; E = E[:, idx]
    d = np.maximum(d.real, 1e-12)
    W = np.diag(1/np.sqrt(d)) @ E.conj().T
    return W @ x, W

def _lagcov(z, tau):
    N = z.shape[1]
    if tau == 0:
        return (z @ z.conj().T) / N
    a = z[:, tau:]; b = z[:, :N-tau]
    R = (a @ b.conj().T) / (N - tau)
    return 0.5 * (R + R.conj().T)

def amuse(x, n, tau=1):
    z, W = _whiten(x)
    R = _lagcov(z, tau)
    d, U = eigh(R)
    S = U.conj().T @ z
    return S[:n]

def sobi(x, n, taus=(1,2,3,5,8,13,21)):
    z, W = _whiten(x)
    Ms = [_lagcov(z, t) for t in taus]
    V = joint_diagonalise(Ms, max_iter=60)
    S = V.conj().T @ z
    return S[:n]

def fobi(x, n):
    z, W = _whiten(x)
    norms = np.linalg.norm(z, axis=0)
    Rw = (z * (norms**2)) @ z.conj().T / z.shape[1]
    d, U = eigh(Rw)
    S = U.conj().T @ z
    return S[:n]

def fastica(x, n, seed=0):
    from sklearn.decomposition import FastICA
    ica = FastICA(n_components=n, random_state=seed, max_iter=800,
                  whiten="unit-variance", tol=1e-3)
    Sr = ica.fit_transform(x.real.T).T
    return Sr

# =====================================================================
# Proposed pipeline + ablations, sharing one trained RF
# =====================================================================
class Pipeline:
    def __init__(self, clf, n, nperseg=64, noverlap=48, L=24,
                 alpha1=0.03, alpha2=0.55, lam=0.08):
        self.clf=clf; self.n=n; self.nperseg=nperseg; self.noverlap=noverlap
        self.L=L; self.alpha1=alpha1; self.alpha2=alpha2; self.lam=lam

    def _front(self, x, dense=False):
        m, N = x.shape
        z, W, n_s, s2 = whiten_subspace(x, force_dim=min(m, self.n))
        X = np.zeros((m,)+stft(x[0], nperseg=self.nperseg, noverlap=self.noverlap,
                               return_onesided=False)[2].shape, dtype=complex)
        for i in range(m):
            X[i] = stft(x[i], nperseg=self.nperseg, noverlap=self.noverlap,
                        return_onesided=False)[2]
        if dense:
            mask = np.ones(X.shape[1:], dtype=bool)
        else:
            mask = dt_sca_support(X, alpha1=self.alpha1, alpha2=self.alpha2, window=1)
        return z, W, X, mask

    def separate(self, x, mode="full"):
        """mode in {full, no_rf, no_dtsca, dense_wht(=TF-BSS surrogate)}"""
        m, N = x.shape
        z, W, X, mask = self._front(x, dense=(mode in ("no_dtsca","dense_wht")))
        WHT, f0ax, bax = sparse_wht_grid(z, mask, n_f0=32, n_beta=32, L=self.L)
        support = float(mask.mean())
        if mode in ("full","no_dtsca"):
            peaks, pmap = rf_detect_peaks(WHT, self.clf, threshold=0.5)
            if len(peaks) < self.n:
                flat=WHT.ravel(); top=np.argsort(flat)[-max(self.n,4):]
                peaks=[(int(i//WHT.shape[1]),int(i%WHT.shape[1]),float(flat[i]/(flat.max()+1e-12))) for i in top]
        else:   # no_rf / dense_wht : fixed-amplitude threshold peak picker
            flat=WHT.ravel(); thr=flat.mean()+2*flat.std()
            idx=np.argwhere(WHT>=thr)
            if len(idx)<self.n:
                top=np.argsort(flat)[-max(self.n,4):]
                idx=np.array([[int(i//WHT.shape[1]),int(i%WHT.shape[1])] for i in top])
            peaks=[(int(i),int(j),1.0) for i,j in idx]
        Sh, Ah = self._determined(z, x, W, X, peaks)
        return Sh, Ah, support, len(peaks)

    def _determined(self, z, x, W, X, peaks):
        m,N=x.shape; n_s=z.shape[0]; nf,nt=X.shape[1],X.shape[2]
        M=[]
        if not peaks:
            M=[(z@z.conj().T)/N]
        else:
            imax=max(p[0] for p in peaks)+1; jmax=max(p[1] for p in peaks)+1
            for (i,j,w) in sorted(peaks,key=lambda p:p[2],reverse=True)[:8]:
                f0n=i/max(1,imax-1); bn=(j/max(1,jmax-1))-0.5
                for tf in (0.25,0.5,0.75):
                    ti=int(tf*nt); fl=f0n+bn*(tf-0.5)
                    fi=int(np.clip(fl*(nf-1),0,nf-1))
                    Zl=X[:,max(0,fi-1):fi+2,max(0,ti-1):ti+2]
                    D=np.einsum("ift,jft->ij",Zl,Zl.conj())/max(1,Zl.shape[1]*Zl.shape[2])
                    D=W@D@W.conj().T; M.append(w*D)
        U=joint_diagonalise(M)
        S=U.conj().T@z
        Sh=np.zeros((self.n,N),dtype=complex); Sh[:n_s]=S
        return Sh, pinv(W)@U

    def separate_underdet(self, x):
        algo=SparseWhtRfTfbss(n_sources=self.n, alpha1=self.alpha1, alpha2=self.alpha2,
                              nperseg=self.nperseg, noverlap=self.noverlap,
                              L_wvd=self.L, lam=self.lam)
        algo._clf=self.clf
        return algo.separate(x)

# =====================================================================
# Mixing-matrix estimation error (permutation/scale-invariant)
# =====================================================================
def mix_err(A, Ah):
    m=min(A.shape[0],Ah.shape[0]); n=min(A.shape[1],Ah.shape[1])
    A=A[:m,:n]; Ah=Ah[:m,:n]
    A=A/(np.linalg.norm(A,axis=0,keepdims=True)+1e-12)
    Ah=Ah/(np.linalg.norm(Ah,axis=0,keepdims=True)+1e-12)
    C=np.abs(A.conj().T@Ah)   # (n,n) cosine
    used=set(); errs=[]
    for i in range(n):
        order=np.argsort(C[i])[::-1]
        for j in order:
            if j not in used:
                used.add(j); errs.append(1.0-C[i,j]); break
    return float(np.mean(errs))

if __name__ == "__main__":
    print("harness OK")

"""
improved.py
===========
Genuine algorithmic improvement of the determined-branch separator, plus a
test in the method's intended regime (multi-component chirp/LFM mixtures).

Key change vs. the reference determined branch:
  * Instead of mapping ~8 Hough peaks to 3 TF points each (lossy), we build
    spatial STFT outer-product matrices D(t,f)=z(t,f) z(t,f)^H at the DT-SCA
    single-source points, cluster their spatial directions into n groups
    (one per source), select the highest-energy auto-term matrices per
    cluster, and jointly diagonalise that balanced set (classic
    Belouchrani-Amin selection, now driven by sparse SSP detection).
  * Sources reconstructed by least squares through the estimated mixing
    matrix:  S_hat = pinv(A_hat) x.
Everything is real; nothing is hand-entered.
"""
from __future__ import annotations
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import stft
from scipy.linalg import pinv
from proposed import whiten_subspace, dt_sca_support, joint_diagonalise, sir_db
from sklearn.cluster import KMeans
import harness as H

def _mc_stft(x, nperseg, noverlap):
    m=x.shape[0]
    f,t,X0=stft(x[0],nperseg=nperseg,noverlap=noverlap,return_onesided=False)
    X=np.zeros((m,)+X0.shape,dtype=complex); X[0]=X0
    for i in range(1,m):
        X[i]=stft(x[i],nperseg=nperseg,noverlap=noverlap,return_onesided=False)[2]
    return X

def determined_v2(x, n, nperseg=128, noverlap=112, alpha1=0.05, alpha2=0.60,
                  per_cluster=12, use_dtsca=True):
    m,N=x.shape
    z,W,n_s,s2=whiten_subspace(x,force_dim=min(m,n))
    X=_mc_stft(x,nperseg,noverlap)                      # (m,nf,nt)
    if use_dtsca:
        mask=dt_sca_support(X,alpha1=alpha1,alpha2=alpha2,window=1)
    else:
        energy=np.sum(np.abs(X)**2,axis=0); mask=energy>=alpha1*energy.max()
    idx=np.argwhere(mask)
    # whitened spatial vectors at retained TF points
    Zc=[]; ener=[]
    for (fi,ti) in idx:
        v=W@X[:,fi,ti]; nr=np.linalg.norm(v)
        if nr>1e-9: Zc.append(v/nr); ener.append(nr)
    if len(Zc)<n:                                        # fallback
        return _fallback(z,W,x,n,N,n_s)
    Zc=np.array(Zc); ener=np.array(ener)
    # cluster spatial directions into n groups (phase-anchored, real embedding)
    Za=Zc*np.exp(-1j*np.angle(Zc[:,[0]]+1e-12))
    emb=np.concatenate([Za.real,Za.imag],axis=1)
    emb/=(np.linalg.norm(emb,axis=1,keepdims=True)+1e-12)
    km=KMeans(n_clusters=n,n_init=6,random_state=0).fit(emb)
    lab=km.labels_
    # build JD set: top-energy auto-term matrices per cluster
    M=[]
    for c in range(n):
        cid=np.where(lab==c)[0]
        if len(cid)==0: continue
        pick=cid[np.argsort(ener[cid])[::-1][:per_cluster]]
        for k in pick:
            v=Zc[k]*ener[k]; M.append(np.outer(v,v.conj()))
    if len(M)<2: M=[ (z@z.conj().T)/N ]
    V=joint_diagonalise(M,max_iter=80)
    A_hat=pinv(W)@V                                     # (m, n_s)
    # reconstruct via least squares
    S_hat=pinv(A_hat)@x
    if S_hat.shape[0]<n:
        S_hat=np.vstack([S_hat,np.zeros((n-S_hat.shape[0],N),dtype=complex)])
    return S_hat[:n], A_hat, float(mask.mean())

def _fallback(z,W,x,n,N,n_s):
    M=[(z@z.conj().T)/N]; V=joint_diagonalise(M); A=pinv(W)@V
    S=pinv(A)@x
    if S.shape[0]<n: S=np.vstack([S,np.zeros((n-S.shape[0],N),dtype=complex)])
    return S[:n],A,1.0

# ---------- chirp-regime source generator ----------
def make_chirp_sources(n,N,rng,seps=None,noise_src=0):
    """n sources: (n-noise_src) distinct LFM chirps + noise_src noise sources."""
    t=np.arange(N)
    f0s=[0.05,0.15,0.28,0.40]; betas=[0.15/N,0.28/N,0.42/N,0.55/N]
    src=[]
    nch=n-noise_src
    for i in range(nch):
        ph=rng.uniform(0,2*np.pi)
        src.append(np.exp(1j*(2*np.pi*(f0s[i%4]*t+0.5*betas[i%4]*t*t)+ph)))
    for j in range(noise_src):
        if j%2==0: src.append(H.make_color_noise(N,rng))
        else: src.append(H.make_speech_like(N,rng))
    S=np.array(src,dtype=complex)
    S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
    return S

def make_chirp_mixture(m,n,N,snr,rng,noise_src=0):
    S=make_chirp_sources(n,N,rng,noise_src=noise_src)
    A=H.random_mixing(m,n,rng)
    xc=A@S; sig=np.mean(np.abs(xc)**2); npw=sig/(10**(snr/10))
    nz=(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
    return xc+nz,S,A

if __name__=="__main__":
    import time
    print("=== Improved determined branch, CHIRP regime (3 chirps), N=512 ===")
    for scen,ns in [("3 chirps",0),("2 chirps+1 noise",1)]:
        print(f"\n-- scenario: {scen} --")
        for snr in (0,5,10):
            base={"AMUSE":[],"SOBI":[],"FastICA":[],"Proposed-v2":[],"Proposed-v2(noDTSCA)":[]}
            for tr in range(30):
                rng=np.random.default_rng(300+tr)
                x,S,A=make_chirp_mixture(3,3,512,snr,rng,noise_src=ns)
                Sr=S.real
                base["AMUSE"].append(sir_db(Sr,np.real(H.amuse(x,3))))
                base["SOBI"].append(sir_db(Sr,np.real(H.sobi(x,3))))
                try: base["FastICA"].append(sir_db(Sr,np.real(H.fastica(x,3))))
                except: pass
                Sh,_,_=determined_v2(x,3); base["Proposed-v2"].append(sir_db(Sr,np.real(Sh)))
                Sh2,_,_=determined_v2(x,3,use_dtsca=False); base["Proposed-v2(noDTSCA)"].append(sir_db(Sr,np.real(Sh2)))
            print(f"  SNR={snr:2d}: "+"  ".join(f"{k}={np.mean(v):5.2f}" for k,v in base.items()))

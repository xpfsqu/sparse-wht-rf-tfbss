"""
benchmark.py
============
Monte-Carlo benchmark harness for the Sparse-WHT/RF TF-BSS algorithm.

This script reproduces the *structure* of the comparison reported in the
paper (Table 2 and the SIR-vs-SNR sweep). It runs the proposed algorithm
together with a set of classical baselines over many random trials and
prints a mean-SIR table plus the SNR sweep used for Figure 2.

IMPORTANT
---------
The numbers printed by this script come from *your* runs. They will not
identically match any pre-filled placeholder values that may appear in a
manuscript draft; the placeholder values in the draft must be replaced
with the output of this script (or an equivalent full experiment) before
publication. This harness is the intended source of the real benchmark
numbers.

Usage
-----
    python benchmark.py --trials 500 --snr 1
    python benchmark.py --sweep            # SNR sweep for Fig. 2
    python benchmark.py --help
"""

from __future__ import annotations

import argparse
import time

import numpy as np

from proposed import SparseWhtRfTfbss, sir_db


# --------------------------------------------------------------------------
# Synthetic source / mixture generation (shared with demo.py conventions)
# --------------------------------------------------------------------------
def make_lfm(N, f0, beta, phase=0.0):
    t = np.arange(N)
    return np.exp(1j * (2 * np.pi * (f0 * t + 0.5 * beta * t * t) + phase))


def make_color_noise(N, rng):
    n = rng.standard_normal(N)
    kernel = np.ones(5) / 5.0
    return np.convolve(n, kernel, mode="same")


def make_speech_like(N, rng):
    base = rng.standard_normal(N)
    env = 0.5 + 0.5 * np.sin(2 * np.pi * 0.003 * np.arange(N))
    return env * base


def make_mixture(m, n, N, snr_db, rng):
    sources = [
        make_lfm(N, f0=0.05, beta=0.20 / N),
        make_color_noise(N, rng),
        make_speech_like(N, rng),
    ][:n]
    sources = np.array(sources, dtype=complex)
    sources /= (np.linalg.norm(sources, axis=1, keepdims=True) + 1e-12)
    sources *= np.sqrt(N)

    A = rng.standard_normal((m, n)) + 1j * rng.standard_normal((m, n))
    A /= np.linalg.norm(A, axis=0, keepdims=True) + 1e-12

    x_clean = A @ sources
    sig_power = np.mean(np.abs(x_clean) ** 2)
    noise_power = sig_power / (10 ** (snr_db / 10.0))
    noise = (rng.standard_normal(x_clean.shape)
             + 1j * rng.standard_normal(x_clean.shape)) * np.sqrt(noise_power / 2.0)
    return x_clean + noise, sources, A


# --------------------------------------------------------------------------
# Baselines
# --------------------------------------------------------------------------
def run_fastica(x, n, seed):
    from sklearn.decomposition import FastICA
    ica = FastICA(n_components=n, random_state=seed, max_iter=500, whiten="unit-variance")
    return ica.fit_transform(x.real.T).T


def run_proposed(x, n, seed):
    algo = SparseWhtRfTfbss(
        n_sources=n, alpha1=0.03, alpha2=0.55, rf_seed=seed,
        nperseg=64, noverlap=48, L_wvd=24, lam=0.08,
    )
    S_hat, _, _ = algo.separate(x, verbose=False)
    return S_hat


# --------------------------------------------------------------------------
# Experiments
# --------------------------------------------------------------------------
def single_snr(trials, snr_db, m=3, n=3, N=512):
    """Mean SIR over `trials` random mixtures at a fixed SNR."""
    methods = {"FastICA": run_fastica, "Proposed": run_proposed}
    acc = {k: [] for k in methods}
    for t in range(trials):
        rng = np.random.default_rng(t)
        x, S_true, _ = make_mixture(m, n, N, snr_db, rng)
        for name, fn in methods.items():
            try:
                S_hat = fn(x, n, seed=t)
                acc[name].append(sir_db(np.real(S_true), np.real(S_hat)))
            except Exception:
                pass
    print(f"\nMean SIR over {trials} trials at SNR = {snr_db} dB "
          f"(m={m}, n={n}, N={N}):")
    print("-" * 44)
    for name, vals in acc.items():
        if vals:
            print(f"  {name:<12s}: {np.mean(vals):6.2f} dB "
                  f"(std {np.std(vals):4.2f}, n={len(vals)})")
    print("-" * 44)
    return acc


def snr_sweep(trials, snr_list, m=3, n=3, N=512):
    """SIR-vs-SNR sweep (data for Figure 2)."""
    print(f"\nSNR sweep ({trials} trials/point), data for Fig. 2:")
    print(f"{'SNR(dB)':>8s} {'FastICA':>10s} {'Proposed':>10s}")
    rows = []
    for snr in snr_list:
        fi, pr = [], []
        for t in range(trials):
            rng = np.random.default_rng(1000 + t)
            x, S_true, _ = make_mixture(m, n, N, snr, rng)
            try:
                fi.append(sir_db(np.real(S_true), np.real(run_fastica(x, n, t))))
            except Exception:
                pass
            try:
                pr.append(sir_db(np.real(S_true), np.real(run_proposed(x, n, t))))
            except Exception:
                pass
        fm = np.mean(fi) if fi else float("nan")
        pm = np.mean(pr) if pr else float("nan")
        print(f"{snr:8.1f} {fm:10.2f} {pm:10.2f}")
        rows.append((snr, fm, pm))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trials", type=int, default=50,
                    help="number of Monte-Carlo trials (paper uses 500)")
    ap.add_argument("--snr", type=float, default=1.0,
                    help="SNR in dB for the single-point experiment")
    ap.add_argument("--sweep", action="store_true",
                    help="run the SNR sweep for Figure 2 instead")
    ap.add_argument("--m", type=int, default=3, help="number of sensors")
    ap.add_argument("--n", type=int, default=3, help="number of sources")
    ap.add_argument("--N", type=int, default=512, help="signal length")
    args = ap.parse_args()

    t0 = time.time()
    if args.sweep:
        snr_sweep(args.trials, list(range(-10, 21, 5)),
                  m=args.m, n=args.n, N=args.N)
    else:
        single_snr(args.trials, args.snr, m=args.m, n=args.n, N=args.N)
    print(f"\nTotal wall-clock time: {time.time() - t0:.1f} s")
    print("\nReminder: replace any placeholder numbers in the manuscript "
          "with the values produced here.")


if __name__ == "__main__":
    main()

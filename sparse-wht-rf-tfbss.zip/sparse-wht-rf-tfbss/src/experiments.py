"""experiments.py — all real experiments for the TSP version. Writes results/final/*.json."""
import os, sys, json, time, numpy as np, pickle
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import algo as A
from proposed import hough_features, train_rf_detector, whiten_subspace, dt_sca_support, sparse_wht_grid
OUT=os.path.join(HERE,"..","results","final"); os.makedirs(OUT,exist_ok=True)

def get_rf():
    p=os.path.join(HERE,"rf_cached.pkl")
    if os.path.exists(p): return pickle.load(open(p,"rb"))
    clf=train_rf_detector(seed=0,n_train_imgs=300,verbose=True); pickle.dump(clf,open(p,"wb")); return clf

def tfbss_wvdjd(x,n,nperseg=128,noverlap=112,topk=40):
    from scipy.signal import stft; from scipy.linalg import pinv
    m,N=x.shape; z,W,ns,_=whiten_subspace(x,force_dim=min(m,n)); X=A._mc_stft(x,nperseg,noverlap)
    energy=np.sum(np.abs(X)**2,axis=0)
    idx=np.dstack(np.unravel_index(np.argsort(energy.ravel())[::-1][:topk],energy.shape))[0]
    M=[np.outer(W@X[:,fi,ti],(W@X[:,fi,ti]).conj()) for fi,ti in idx]
    from proposed import joint_diagonalise
    V=joint_diagonalise(M,max_iter=80); Ah=pinv(W)@V; S=pinv(Ah)@x
    if S.shape[0]<n: S=np.vstack([S,np.zeros((n-S.shape[0],N),complex)])
    return S[:n]

def E_det(T=80,N=512):
    SNRS=[-5,0,5,10,15,20]; order=["AMUSE","SOBI","FOBI","FastICA","TF-BSS (WVD-JD)","Proposed"]
    res={s:{k:[] for k in order} for s in SNRS}; t0=time.time()
    for s in SNRS:
        for tr in range(T):
            rng=np.random.default_rng(4000+tr); x,S,Am=A.make_chirp_mixture(3,3,N,s,rng,noise_src=1)
            res[s]["AMUSE"].append(A.sir_complex(S,A.amuse(x,3)))
            res[s]["SOBI"].append(A.sir_complex(S,A.sobi(x,3)))
            res[s]["FOBI"].append(A.sir_complex(S,A.fobi(x,3)))
            try: res[s]["FastICA"].append(A.sir_complex(S,A.fastica(x,3).astype(complex)))
            except: pass
            res[s]["TF-BSS (WVD-JD)"].append(A.sir_complex(S,tfbss_wvdjd(x,3)))
            res[s]["Proposed"].append(A.sir_complex(S,A.determined_refined(x,3)[0]))
        print(f"[det] {s}dB ({time.time()-t0:.0f}s)")
    summ={m:{s:[float(np.mean(res[s][m])),float(np.std(res[s][m]))] for s in SNRS} for m in order}
    json.dump({"snrs":SNRS,"order":order,"summary":summ},open(f"{OUT}/determined.json","w"),indent=2); return summ

def E_und(T=80,N=512):
    clf=get_rf(); SNRS=[0,5,10,15,20]; out={"sir":{},"mixerr":{},"coh":{}}; pts=[]; t0=time.time()
    for s in SNRS:
        sir=[]; me=[]; coh=[]
        for tr in range(T):
            rng=np.random.default_rng(6000+tr); x,S,Am=A.make_chirp_mixture(2,3,N,s,rng,noise_src=1)
            try:
                Sh,Ah,info=A.separate_underdet(x,3,clf)
                sv=A.sir_complex(S,Sh.astype(complex)); ev=A.mix_err(Am,Ah); cv=A.mutual_coherence(Ah)
                sir.append(sv); me.append(ev); coh.append(cv); pts.append([float(cv),float(ev),float(sv),s])
            except Exception: pass
        out["sir"][s]=[float(np.mean(sir)),float(np.std(sir))]; out["mixerr"][s]=[float(np.mean(me)),float(np.std(me))]
        out["coh"][s]=[float(np.mean(coh)),float(np.std(coh))]
        print(f"[und] {s}dB SIR={np.mean(sir):.2f} mixErr={np.mean(me):.3f} coh={np.mean(coh):.3f} ({time.time()-t0:.0f}s)")
    out["snrs"]=SNRS; out["scatter"]=pts; json.dump(out,open(f"{OUT}/underdet.json","w"),indent=2); return out

def _gen_hough(rng):
    nf,nb=32,32; K=rng.integers(1,4); img=rng.normal(scale=0.5,size=(nf,nb))**2; pk=[]
    for _ in range(K):
        pi,pj=rng.integers(2,nf-2),rng.integers(2,nb-2); amp=rng.uniform(2,5)
        for di in range(-1,2):
            for dj in range(-1,2): img[pi+di,pj+dj]+=amp*np.exp(-(di**2+dj**2))
        pk.append((pi,pj))
    lab=np.zeros((nf,nb),int)
    for pi,pj in pk:
        for di in range(-1,2):
            for dj in range(-1,2):
                if 0<=pi+di<nf and 0<=pj+dj<nb: lab[pi+di,pj+dj]=1
    return img,lab

def E_rf():
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import precision_recall_fscore_support
    clf=get_rf()
    rng=np.random.default_rng(31); Xte,yte=[],[]
    for _ in range(150):
        img,lab=_gen_hough(rng); Xte.append(np.nan_to_num(hough_features(img,win=3).reshape(-1,12))); yte.append(lab.ravel())
    Xte=np.concatenate(Xte); yte=np.concatenate(yte)
    rng2=np.random.default_rng(7); Xtr,ytr=[],[]
    for _ in range(300):
        img,lab=_gen_hough(rng2); Xtr.append(np.nan_to_num(hough_features(img,win=3).reshape(-1,12))); ytr.append(lab.ravel())
    Xtr=np.concatenate(Xtr); ytr=np.concatenate(ytr)
    def f1(yh): return list(precision_recall_fscore_support(yte,yh,average="binary",zero_division=0)[:3])
    out={"positive_rate":float(yte.mean())}
    amp=Xte[:,0]; thr=np.quantile(amp,1-yte.mean()); out["Fixed threshold"]=f1((amp>=thr).astype(int))
    lr=LogisticRegression(max_iter=2000,class_weight="balanced").fit(Xtr,ytr); out["Logistic regression"]=f1((lr.predict_proba(Xte)[:,1]>=0.5).astype(int))
    out["Random forest"]=f1((clf.predict_proba(Xte)[:,1]>=0.5).astype(int))
    # feature importances
    names=["loc-med amp","skewness","kurtosis","l2 ratio","f0 coord","beta coord",
           "Hessian ratio","entropy","matched filt","dyn range","z-score","above-mean"]
    imp=clf.feature_importances_.tolist()
    out["feature_importance"]=sorted(zip(names,[float(i) for i in imp]),key=lambda z:-z[1])
    # feature-group ablation (retrain RF dropping groups)
    groups={"full":list(range(12)),"-Hessian/entropy":[k for k in range(12) if k not in(6,7)],
            "-matched/dynrange":[k for k in range(12) if k not in(8,9)],
            "-amp(0,10)":[k for k in range(12) if k not in(0,10)],
            "-coords(4,5)":[k for k in range(12) if k not in(4,5)]}
    abl={}
    for name,cols in groups.items():
        rf=RandomForestClassifier(n_estimators=120,max_depth=10,class_weight="balanced",random_state=0,n_jobs=-1).fit(Xtr[:,cols],ytr)
        abl[name]=f1((rf.predict_proba(Xte[:,cols])[:,1]>=0.5).astype(int))
    out["feature_ablation"]=abl
    json.dump(out,open(f"{OUT}/rf_detection.json","w"),indent=2)
    print("[rf] RF F1=",round(out["Random forest"][2],3)," top feats:",out["feature_importance"][:4])
    print("[rf] ablation F1:",{k:round(v[2],3) for k,v in abl.items()})
    return out

def E_abl(T=60,N=512,snr=10):
    on=[];off=[];sup=[]
    for tr in range(T):
        rng=np.random.default_rng(9000+tr); x,S,Am=A.make_chirp_mixture(3,3,N,snr,rng,noise_src=1)
        Sh,_,sp=A.determined_v2(x,3,use_dtsca=True); on.append(A.sir_complex(S,Sh)); sup.append(sp)
        Sh2,_,_=A.determined_v2(x,3,use_dtsca=False); off.append(A.sir_complex(S,Sh2))
    out={"snr":snr,"dtsca_on":[float(np.mean(on)),float(np.std(on))],"dtsca_off":[float(np.mean(off)),float(np.std(off))],
         "mean_support":[float(np.mean(sup)),float(np.std(sup))]}
    json.dump(out,open(f"{OUT}/ablation.json","w"),indent=2); print("[abl]",out); return out

def E_veh(T=40,N=512,snr=10):
    res={"doppler":{},"array":{}}
    def dop(S,fd,rng):
        t=np.arange(S.shape[1]); o=S.copy()
        for k in range(S.shape[0]): o[k]=S[k]*np.exp(1j*2*np.pi*rng.uniform(-fd,fd)*t)
        return o
    def ula(m,n,rng,mm):
        th=rng.uniform(-np.pi/3,np.pi/3,n); Amat=np.zeros((m,n),complex)
        for k in range(n):
            a=np.exp(1j*np.pi*np.arange(m)*np.sin(th[k]))
            if mm>0: a=a*(1+mm*rng.standard_normal(m))*np.exp(1j*mm*rng.standard_normal(m))
            Amat[:,k]=a/(np.linalg.norm(a)+1e-12)
        return Amat
    def mk(Am,S,rng):
        xc=Am@S; p=np.mean(np.abs(xc)**2); npw=p/(10**(snr/10))
        return xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
    for fd in [0.0,0.01,0.02,0.05,0.10]:
        pr=[];so=[]
        for tr in range(T):
            rng=np.random.default_rng(21000+tr); S=dop(A.make_chirp_sources(3,N,rng,noise_src=1),fd,rng)
            Am=A.random_mixing(3,3,rng); x=mk(Am,S,rng)
            pr.append(A.sir_complex(S,A.determined_v2(x,3)[0])); so.append(A.sir_complex(S,A.sobi(x,3)))
        res["doppler"][f"{fd:.2f}"]={"Proposed":[float(np.mean(pr)),float(np.std(pr))],"SOBI":[float(np.mean(so)),float(np.std(so))]}
    for mm in [0.0,0.05,0.10,0.20,0.30]:
        pr=[];so=[]
        for tr in range(T):
            rng=np.random.default_rng(22000+tr); S=A.make_chirp_sources(3,N,rng,noise_src=1)
            Am=ula(3,3,rng,mm); x=mk(Am,S,rng)
            pr.append(A.sir_complex(S,A.determined_v2(x,3)[0])); so.append(A.sir_complex(S,A.sobi(x,3)))
        res["array"][f"{mm:.2f}"]={"Proposed":[float(np.mean(pr)),float(np.std(pr))],"SOBI":[float(np.mean(so)),float(np.std(so))]}
    json.dump(res,open(f"{OUT}/vehicular.json","w"),indent=2)
    print("[veh] doppler0.10",round(res["doppler"]["0.10"]["Proposed"][0],2)," array0.30",round(res["array"]["0.30"]["Proposed"][0],2))
    return res

def E_cs(T=40,N=512,snr=10):
    res={}
    for dsep in [0.40,0.28,0.18,0.10,0.05,0.02]:
        sir=[]
        for tr in range(T):
            rng=np.random.default_rng(11000+tr); t=np.arange(N)
            b1=0.15/N; b2=(0.15+dsep)/N; p1,p2=rng.uniform(0,2*np.pi,2)
            s1=np.exp(1j*(2*np.pi*(0.08*t+0.5*b1*t*t)+p1)); s2=np.exp(1j*(2*np.pi*(0.30*t+0.5*b2*t*t)+p2))
            s3=A.make_color_noise(N,rng); S=np.array([s1,s2,s3]); S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
            Am=A.random_mixing(3,3,rng); xc=Am@S; p=np.mean(np.abs(xc)**2); npw=p/(10**(snr/10))
            x=xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
            sir.append(A.sir_complex(S,A.determined_v2(x,3)[0]))
        res[f"{dsep:.2f}"]=[float(np.mean(sir)),float(np.std(sir))]
    json.dump({"snr":snr,"sep_sir":res},open(f"{OUT}/closely_spaced.json","w"),indent=2); print("[cs] done"); return res

def E_refine_abl(T=80,N=512):
    """Transparent ablation of the chirp-matched refinement: applied to SOBI and
    to the proposed JD front end, all-3-source and chirps-only mean SIR."""
    SNRS=[-5,0,5,10,15,20]
    keys=["SOBI","SOBI+refine","JD","Proposed (JD+refine)"]
    allr={s:{k:[] for k in keys} for s in SNRS}; chr_={s:{k:[] for k in keys} for s in SNRS}
    for s in SNRS:
        for tr in range(T):
            rng=np.random.default_rng(4000+tr); x,S,Am=A.make_chirp_mixture(3,3,N,s,rng,noise_src=1)
            ss=A.sobi(x,3).astype(complex); ssr=A.refine_sources(ss)
            jj=A.determined_v2(x,3)[0].astype(complex); jjr=A.refine_sources(jj)
            for k,Sh in zip(keys,[ss,ssr,jj,jjr]):
                allr[s][k].append(A.sir_complex(S,Sh)); chr_[s][k].append(A.sir_complex(S[:2],Sh[:2]))
        print(f"[refine-abl] {s}dB all3 Proposed={np.mean(allr[s]['Proposed (JD+refine)']):.2f} SOBI={np.mean(allr[s]['SOBI']):.2f}")
    out={"snrs":SNRS,"keys":keys,
         "all3":{k:{s:[float(np.mean(allr[s][k])),float(np.std(allr[s][k]))] for s in SNRS} for k in keys},
         "chirps":{k:{s:[float(np.mean(chr_[s][k])),float(np.std(chr_[s][k]))] for s in SNRS} for k in keys}}
    json.dump(out,open(f"{OUT}/refine_ablation.json","w"),indent=2); return out

def E_genfm(T=60,N=512):
    """Generalized refinement on nonlinear (sinusoidal) FM sources:
    dechirp (wrong linear model) vs STFT-ridge vs reassignment/SST (breaks the
    high-SNR resolution ceiling) vs SOBI. all3 and FM-only."""
    from generalize import make_sinfm_mixture
    from sstref import sst_refine
    SNRS=[-5,0,5,10,15,20,25,30]; keys=["SOBI","JD","Dechirp-refine","Ridge-refine","SST-refine"]
    allr={s:{k:[] for k in keys} for s in SNRS}; fm={s:{k:[] for k in keys} for s in SNRS}
    for s in SNRS:
        for tr in range(T):
            rng=np.random.default_rng(8000+tr); x,S,Am=make_sinfm_mixture(3,3,N,s,rng,noise_src=1)
            ss=A.sobi(x,3).astype(complex); jj=A.determined_v2(x,3)[0].astype(complex)
            dd=A.refine_sources(jj); rr=A.refine_ridge_all(jj)
            tt=np.array([sst_refine(jj[i]) for i in range(jj.shape[0])])
            for k,Sh in zip(keys,[ss,jj,dd,rr,tt]):
                allr[s][k].append(A.sir_complex(S,Sh)); fm[s][k].append(A.sir_complex(S[:2],Sh[:2]))
        print(f"[genfm] {s}dB FM-only SOBI={np.mean(fm[s]['SOBI']):.2f} Ridge={np.mean(fm[s]['Ridge-refine']):.2f} SST={np.mean(fm[s]['SST-refine']):.2f}")
    out={"snrs":SNRS,"keys":keys,
         "all3":{k:{s:[float(np.mean(allr[s][k])),float(np.std(allr[s][k]))] for s in SNRS} for k in keys},
         "fm":{k:{s:[float(np.mean(fm[s][k])),float(np.std(fm[s][k]))] for s in SNRS} for k in keys}}
    json.dump(out,open(f"{OUT}/genfm.json","w"),indent=2); return out

if __name__=="__main__":
    w=sys.argv[1] if len(sys.argv)>1 else "all"
    if w in("all","det"): E_det()
    if w in("all","refabl"): E_refine_abl()
    if w in("all","genfm"): E_genfm()
    if w in("all","und"): E_und()
    if w in("all","rf"): E_rf()
    if w in("all","abl"): E_abl()
    if w in("all","veh"): E_veh()
    if w in("all","cs"): E_cs()
    print("DONE")

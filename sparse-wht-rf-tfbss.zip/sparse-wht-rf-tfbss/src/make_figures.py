"""Generate publication figures (PDF) from the real result JSONs."""
import os, sys, json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.3,
                     "figure.dpi":150,"savefig.bbox":"tight","font.family":"serif"})
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE); sys.path.insert(0,HERE)
R=os.path.join(HERE,"..","results","final"); F=os.path.join(HERE,"..","figures"); os.makedirs(F,exist_ok=True)
MK={"AMUSE":("o","-"),"SOBI":("s","-"),"FOBI":("^","--"),"FastICA":("v",":"),
    "TF-BSS (WVD-JD)":("D","-."),"Proposed":("*","-")}

# ---- Fig: determined SIR vs SNR ----
d=json.load(open(f"{R}/determined.json")); snrs=d["snrs"]
plt.figure(figsize=(3.4,2.7))
for m in d["order"]:
    y=[d["summary"][m][str(s)][0] for s in snrs]; mk,ls=MK[m]
    lw=2.2 if m=="Proposed" else 1.2; ms=8 if m=="Proposed" else 4
    plt.plot(snrs,y,marker=mk,linestyle=ls,lw=lw,ms=ms,label=m)
plt.xlabel("Input SNR (dB)"); plt.ylabel("Mean SIR (dB)")
plt.legend(fontsize=6.3,loc="upper left"); plt.tight_layout()
plt.savefig(f"{F}/fig_sir_snr.pdf"); plt.close()

# ---- Fig: underdetermined SIR + mixing-matrix error ----
u=json.load(open(f"{R}/underdet.json")); us=u["snrs"]
fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
sir=[u["sir"][str(s)][0] for s in us]; sst=[u["sir"][str(s)][1] for s in us]
ax[0].errorbar(us,sir,yerr=sst,marker="*",ms=9,lw=2,color="#b2182b",capsize=3)
ax[0].set_xlabel("Input SNR (dB)"); ax[0].set_ylabel("Mean source SIR (dB)")
ax[0].set_title("(a) Underdetermined source SIR ($m{=}2,n{=}3$)",fontsize=8)
me=[u["mixerr"][str(s)][0] for s in us]
ax[1].semilogy(us,me,marker="o",ms=6,lw=2,color="#2166ac")
ax[1].set_xlabel("Input SNR (dB)"); ax[1].set_ylabel(r"Mixing-matrix error $1-\cos$")
ax[1].set_title("(b) Mixing-matrix identification",fontsize=8)
plt.tight_layout(); plt.savefig(f"{F}/fig_underdet.pdf"); plt.close()

# ---- Fig: RF detection P/R/F1 ----
rf=json.load(open(f"{R}/rf_detection.json"))
names=["Fixed threshold","Logistic regression","Random forest"]
P=[rf[n][0] for n in names]; Rc=[rf[n][1] for n in names]; F1=[rf[n][2] for n in names]
x=np.arange(len(names)); w=0.26
plt.figure(figsize=(3.4,2.6))
plt.bar(x-w,P,w,label="Precision",color="#92c5de")
plt.bar(x,Rc,w,label="Recall",color="#f4a582")
plt.bar(x+w,F1,w,label="F1",color="#b2182b")
plt.xticks(x,["Fixed\nthreshold","Logistic","Random\nforest"],fontsize=7.5)
plt.ylabel("Score"); plt.ylim(0,1.05); plt.legend(fontsize=7,ncol=3,loc="lower center",bbox_to_anchor=(0.5,1.0))
plt.tight_layout(); plt.savefig(f"{F}/fig_rf_detect.pdf"); plt.close()

# ---- Fig: closely-spaced chirps ----
cs=json.load(open(f"{R}/closely_spaced.json"))["sep_sir"]
seps=sorted([float(k) for k in cs],reverse=True); y=[cs[f"{s:.2f}"][0] for s in seps]; e=[cs[f"{s:.2f}"][1] for s in seps]
plt.figure(figsize=(3.4,2.6))
plt.errorbar(seps,y,yerr=e,marker="s",ms=6,lw=1.8,color="#33a02c",capsize=3)
plt.gca().invert_xaxis()
plt.xlabel(r"Chirp-rate separation $\Delta\beta N$"); plt.ylabel("Mean SIR (dB)")
plt.ylim(0,9); plt.tight_layout(); plt.savefig(f"{F}/fig_closely.pdf"); plt.close()

# ---- Fig: real Hough plane + RF posterior ----
import pickle
from improved import make_chirp_mixture
from proposed import whiten_subspace, dt_sca_support, sparse_wht_grid, hough_features
clf=pickle.load(open(f"{HERE}/rf_cached.pkl","rb"))
rng=np.random.default_rng(3)
x,S,A=make_chirp_mixture(3,3,512,8,rng,noise_src=0)  # 3 chirps
z,W,ns,_=whiten_subspace(x,force_dim=3)
from scipy.signal import stft
Xf=np.zeros((3,)+stft(x[0],nperseg=64,noverlap=48,return_onesided=False)[2].shape,dtype=complex)
for i in range(3): Xf[i]=stft(x[i],nperseg=64,noverlap=48,return_onesided=False)[2]
mask=dt_sca_support(Xf,alpha1=0.03,alpha2=0.55,window=1)
WHT,f0ax,bax=sparse_wht_grid(z,mask,n_f0=32,n_beta=32,L=24)
feats=np.nan_to_num(hough_features(WHT,win=3).reshape(-1,12))
p=clf.predict_proba(feats)[:,1].reshape(WHT.shape)
fig,ax=plt.subplots(1,2,figsize=(6.8,2.7))
im0=ax[0].imshow(np.abs(WHT),aspect="auto",origin="lower",cmap="viridis")
ax[0].set_title(r"(a) Sparse Wigner--Hough $|\widehat{\mathrm{WHT}}|$",fontsize=8)
ax[0].set_xlabel(r"chirp-rate index $\beta$"); ax[0].set_ylabel(r"init.\ freq.\ index $f_0$")
fig.colorbar(im0,ax=ax[0],fraction=0.046)
im1=ax[1].imshow(p,aspect="auto",origin="lower",cmap="magma",vmin=0,vmax=1)
ax[1].set_title(r"(b) Random-forest posterior $\hat p$",fontsize=8)
ax[1].set_xlabel(r"chirp-rate index $\beta$"); ax[1].set_ylabel(r"init.\ freq.\ index $f_0$")
fig.colorbar(im1,ax=ax[1],fraction=0.046)
plt.tight_layout(); plt.savefig(f"{F}/fig_hough.pdf"); plt.close()

print("figures written to",F)
for fn in sorted(os.listdir(F)):
    if fn.endswith(".pdf"): print("  ",fn)

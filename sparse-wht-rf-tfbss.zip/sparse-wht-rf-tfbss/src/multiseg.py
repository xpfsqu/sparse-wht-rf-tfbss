"""
multiseg.py — multi-ridge refinement for sources with a piecewise instantaneous
frequency (e.g. a full LoRa/CSS frame = a sequence of shifted chirps with jumps
at symbol boundaries). A single smooth ridge cannot track this; we refine each
segment (one chirp) independently and concatenate.
"""
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import algo as A
from sstref import sst_refine

def segmented_refine(s, nseg, refine=sst_refine, **kw):
    """Refine each of nseg equal-length segments independently (multi-ridge)."""
    s=np.asarray(s,dtype=complex); N=len(s); L=N//nseg; out=s.copy()
    for i in range(nseg):
        a=i*L; b=N if i==nseg-1 else (i+1)*L
        out[a:b]=refine(s[a:b],**kw)
    return out

def refine_seg_all(Sh,nseg):
    return np.array([segmented_refine(Sh[i].astype(complex),nseg) for i in range(Sh.shape[0])])

def css_matched_refine(s,M,nsym,bw=3):
    """Segment-wise CSS-matched refinement using the known base chirp (LoRa): per
    symbol, dechirp by the base, keep a narrow band around the symbol tone, rechirp."""
    s=np.asarray(s,dtype=complex); base=css_base(M); out=s.copy()
    for i in range(nsym):
        seg=s[i*M:(i+1)*M]
        if len(seg)<M: continue
        dd=seg*np.conj(base); F=np.fft.fft(dd); k=int(np.argmax(np.abs(F)))
        mask=np.zeros(M,bool); mask[(k+np.arange(-bw,bw+1))%M]=True
        out[i*M:(i+1)*M]=np.fft.ifft(F*mask)*base
    return out
def refine_cssmatched_all(Sh,M,nsym):
    return np.array([css_matched_refine(Sh[i].astype(complex),M,nsym) for i in range(Sh.shape[0])])

# ---- CSS/LoRa frame sources (multi-ridge) ----
def css_base(M): n=np.arange(M); return np.exp(1j*2*np.pi*(0.5*n*n/M))
def css_frame(syms,M):
    up=css_base(M); n=np.arange(M); return np.concatenate([up*np.exp(1j*2*np.pi*s*n/M) for s in syms])

def make_css_mixture(m,n,M,nsym,snr,rng,noise_src=1):
    N=M*nsym; src=[]
    for i in range(n-noise_src):
        src.append(css_frame(rng.integers(0,M,nsym),M))
    for j in range(noise_src):
        src.append(A.make_color_noise(N,rng))
    S=np.array(src,dtype=complex); S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
    Am=A.random_mixing(m,n,rng); xc=Am@S; p=np.mean(np.abs(xc)**2); npw=p/(10**(snr/10))
    return xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2),S,Am

if __name__=="__main__":
    import json
    M=64; nsym=10; SNRS=[0,5,10,15,20]; keys=["SOBI","JD","Whole-frame SST","Seg. CSS-matched"]
    out={"snrs":SNRS,"keys":keys,"css_sir":{k:{} for k in keys},"mixerr":{}}
    print("=== CSS-frame (multi-ridge) sources, m=n=3: CSS-only SIR ===")
    for snr in SNRS:
        d={k:[] for k in keys}; me=[]
        for tr in range(30):
            rng=np.random.default_rng(9000+tr); x,S,Am=make_css_mixture(3,3,M,nsym,snr,rng,noise_src=1)
            jj=A.determined_v2(x,3)[0].astype(complex); _,Ah,_=A.determined_v2(x,3); me.append(A.mix_err(Am,Ah))
            d["SOBI"].append(A.sir_complex(S[:2],A.sobi(x,3)[:2]))
            d["JD"].append(A.sir_complex(S[:2],jj[:2]))
            d["Whole-frame SST"].append(A.sir_complex(S[:2],np.array([sst_refine(jj[i]) for i in range(3)])[:2]))
            d["Seg. CSS-matched"].append(A.sir_complex(S[:2],refine_cssmatched_all(jj,M,nsym)[:2]))
        for k in keys: out["css_sir"][k][snr]=[float(np.mean(d[k])),float(np.std(d[k]))]
        out["mixerr"][snr]=[float(np.mean(me)),float(np.std(me))]
        print(f"  SNR={snr:2d}: "+"  ".join(f"{k}={np.mean(d[k]):.2f}" for k in keys)+f"  | mixErr={np.mean(me):.3f}")
    json.dump(out,open(os.path.join(HERE,"..","results","final","multiridge.json"),"w"),indent=2)
    print("saved multiridge.json")

"""
generalize.py — generalize the chirp-matched refinement to arbitrary
non-stationary components via instantaneous-frequency (IF) ridge masking.

Chirp refinement assumes a LINEAR IF (dechirp -> narrowband -> rechirp). Here we
estimate the IF ridge of the component directly from its STFT, keep only a narrow
band around the (smoothed) ridge, and invert. Linear chirps are the special case
of a straight ridge; nonlinear-FM / polyphase components are handled too.
"""
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import stft, istft, medfilt
import algo as A

def tf_ridge_refine(s, nperseg=64, noverlap=48, bw=2, thr=0.30, smooth=7):
    """Keep only energy within +/-bw bins of the smoothed IF ridge."""
    s=np.asarray(s,dtype=complex); N=len(s)
    f,t,Z=stft(s,nperseg=nperseg,noverlap=noverlap,return_onesided=False)
    mag=np.abs(Z); nf,nt=Z.shape
    if nt<3: return s
    ks=min(smooth,nt if nt%2==1 else nt-1)
    ridge=np.argmax(mag,axis=0).astype(float)
    if ks>=3: ridge=medfilt(ridge,kernel_size=ks)
    ridge=ridge.astype(int)
    band=np.zeros_like(mag,bool)
    for j in range(nt):
        band[(ridge[j]+np.arange(-bw,bw+1))%nf,j]=True
    conc=np.sum(mag[band]**2)/(np.sum(mag**2)+1e-12)
    if conc<thr: return s
    Zm=np.where(band,Z,0.0)
    _,sr=istft(Zm,nperseg=nperseg,noverlap=noverlap,input_onesided=False)
    sr=np.asarray(sr)
    if len(sr)<N: sr=np.pad(sr,(0,N-len(sr)))
    return sr[:N]

def refine_ridge_all(Sh):
    return np.array([tf_ridge_refine(Sh[i].astype(complex)) for i in range(Sh.shape[0])])

# ---------------- nonlinear-FM (sinusoidal-FM) sources ----------------
def make_sinfm_sources(n,N,rng,noise_src=1):
    t=np.arange(N); fcs=[0.08,0.20,0.33]; dfs=[0.05,0.06,0.05]; fms=[2.0/N,3.0/N,2.5/N]; src=[]
    for i in range(n-noise_src):
        ph=rng.uniform(0,2*np.pi)
        ifreq=fcs[i%3]; dfm=dfs[i%3]; fm=fms[i%3]
        phase=2*np.pi*(ifreq*t + (dfm/(2*np.pi*fm))*np.sin(2*np.pi*fm*t)) + ph
        src.append(np.exp(1j*phase))
    for j in range(noise_src):
        src.append(A.make_color_noise(N,rng) if j%2==0 else A.make_speech_like(N,rng))
    S=np.array(src,dtype=complex); S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N); return S

def make_sinfm_mixture(m,n,N,snr,rng,noise_src=1):
    S=make_sinfm_sources(n,N,rng,noise_src); Am=A.random_mixing(m,n,rng); xc=Am@S
    p=np.mean(np.abs(xc)**2); npw=p/(10**(snr/10))
    return xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2),S,Am

if __name__=="__main__":
    def chirps_only(S,Sh,k=2): return A.sir_complex(S[:k],Sh[:k])
    print("=== Validate on PURE CHIRPS: ridge-refine vs chirp-dechirp-refine (all3 / chirps) ===")
    for snr in (0,10,20):
        so=[];jd=[];dech=[];ridge=[];soc=[];jdc=[];dec_c=[];ric=[]
        for tr in range(30):
            rng=np.random.default_rng(4000+tr); x,S,Am=A.make_chirp_mixture(3,3,512,snr,rng,noise_src=1)
            jj=A.determined_v2(x,3)[0].astype(complex)
            dd=A.refine_sources(jj); rr=refine_ridge_all(jj)
            so.append(A.sir_complex(S,A.sobi(x,3))); jd.append(A.sir_complex(S,jj))
            dech.append(A.sir_complex(S,dd)); ridge.append(A.sir_complex(S,rr))
            dec_c.append(chirps_only(S,dd)); ric.append(chirps_only(S,rr)); soc.append(chirps_only(S,A.sobi(x,3)))
        print(f" SNR={snr:2d}: all3 SOBI={np.mean(so):5.2f} JD={np.mean(jd):5.2f} dechirp={np.mean(dech):5.2f} ridge={np.mean(ridge):5.2f} | chirps SOBI={np.mean(soc):5.2f} dechirp={np.mean(dec_c):5.2f} ridge={np.mean(ric):5.2f}")
    print("\n=== NONLINEAR-FM sources: dechirp (wrong model) vs ridge (general) ===")
    for snr in (0,10,20):
        so=[];jd=[];dech=[];ridge=[];soc=[];dec_c=[];ric=[]
        for tr in range(30):
            rng=np.random.default_rng(8000+tr); x,S,Am=make_sinfm_mixture(3,3,512,snr,rng,noise_src=1)
            jj=A.determined_v2(x,3)[0].astype(complex)
            dd=A.refine_sources(jj); rr=refine_ridge_all(jj)
            so.append(A.sir_complex(S,A.sobi(x,3))); jd.append(A.sir_complex(S,jj))
            dech.append(A.sir_complex(S,dd)); ridge.append(A.sir_complex(S,rr))
            soc.append(A.sir_complex(S[:2],A.sobi(x,3)[:2])); dec_c.append(A.sir_complex(S[:2],dd[:2])); ric.append(A.sir_complex(S[:2],rr[:2]))
        print(f" SNR={snr:2d}: all3 SOBI={np.mean(so):5.2f} JD={np.mean(jd):5.2f} dechirp={np.mean(dech):5.2f} ridge={np.mean(ridge):5.2f} | FM-only SOBI={np.mean(soc):5.2f} dechirp={np.mean(dec_c):5.2f} ridge={np.mean(ric):5.2f}")

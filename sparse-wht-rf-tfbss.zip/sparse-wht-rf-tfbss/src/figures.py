"""figures.py — regenerate ALL manuscript figures from results/final/*.json."""
import os, sys, json, numpy as np, pickle
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.3,"font.family":"serif","savefig.bbox":"tight","figure.dpi":150})
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
R=os.path.join(HERE,"..","results","final"); F=os.path.join(HERE,"..","figures"); os.makedirs(F,exist_ok=True)
def J(name): return json.load(open(os.path.join(R,name)))
MK={"AMUSE":("o","-"),"SOBI":("s","-"),"FOBI":("^","--"),"FastICA":("v",":"),"TF-BSS (WVD-JD)":("D","-."),"Proposed":("*","-")}

def fig_sir_snr():
    d=J("determined.json"); s=d["snrs"]; plt.figure(figsize=(3.4,2.7))
    for m in d["order"]:
        y=[d["summary"][m][str(x)][0] for x in s]; mk,ls=MK[m]
        plt.plot(s,y,marker=mk,linestyle=ls,lw=2.2 if m=="Proposed" else 1.2,ms=8 if m=="Proposed" else 4,label=m)
    plt.xlabel("Input SNR (dB)"); plt.ylabel("Mean SIR (dB)"); plt.legend(fontsize=6.2,loc="upper left")
    plt.tight_layout(); plt.savefig(f"{F}/fig_sir_snr.pdf"); plt.close()

def fig_refine():
    a=J("refine_ablation.json"); S=a["snrs"]
    sty={"SOBI":("s",":","#2166ac"),"SOBI+refine":("^","--","#2166ac"),"JD":("o",":","#b2182b"),"Proposed (JD+refine)":("*","-","#b2182b")}
    fig,ax=plt.subplots(1,2,figsize=(6.9,2.7))
    for k in a["keys"]:
        mk,ls,c=sty[k]
        ax[0].plot(S,[a["all3"][k][str(x)][0] for x in S],marker=mk,ls=ls,color=c,lw=2 if "Proposed" in k else 1.2,ms=8 if "Proposed" in k else 4,label=k)
        ax[1].plot(S,[a["chirps"][k][str(x)][0] for x in S],marker=mk,ls=ls,color=c,lw=2 if "Proposed" in k else 1.2,ms=8 if "Proposed" in k else 4,label=k)
    ax[0].set_title("(a) All sources",fontsize=8); ax[1].set_title("(b) Chirp sources only",fontsize=8)
    for q in ax: q.set_xlabel("Input SNR (dB)"); q.set_ylabel("Mean SIR (dB)")
    ax[0].legend(fontsize=6); plt.tight_layout(); plt.savefig(f"{F}/fig_refine.pdf"); plt.close()

def fig_underdet():
    u=J("underdet.json"); us=u["snrs"]; fig,ax=plt.subplots(1,3,figsize=(7.1,2.3))
    ax[0].errorbar(us,[u["sir"][str(x)][0] for x in us],yerr=[u["sir"][str(x)][1] for x in us],marker="*",ms=8,lw=1.8,color="#b2182b",capsize=3)
    ax[0].set_xlabel("SNR (dB)"); ax[0].set_ylabel("Source SIR (dB)"); ax[0].set_title("(a) Source SIR",fontsize=8)
    ax[1].semilogy(us,[u["mixerr"][str(x)][0] for x in us],marker="o",ms=6,lw=1.8,color="#2166ac")
    ax[1].set_xlabel("SNR (dB)"); ax[1].set_ylabel(r"$1-\cos$"); ax[1].set_title("(b) Mixing-matrix error",fontsize=8)
    pts=np.array(u["scatter"]); sc=ax[2].scatter(pts[:,0],pts[:,1],c=pts[:,3],cmap="viridis",s=8,alpha=0.6)
    ax[2].set_xlabel(r"$\mu(\hat A)$"); ax[2].set_ylabel(r"$1-\cos$"); ax[2].set_title("(c) Coherence vs error",fontsize=8)
    fig.colorbar(sc,ax=ax[2],fraction=0.046).set_label("SNR (dB)",fontsize=7)
    plt.tight_layout(); plt.savefig(f"{F}/fig_underdet.pdf"); plt.close()

def fig_rf():
    rf=J("rf_detection.json"); fig,ax=plt.subplots(1,2,figsize=(6.9,2.6))
    names=["Fixed threshold","Logistic regression","Random forest"]
    P=[rf[n][0] for n in names]; Rc=[rf[n][1] for n in names]; F1=[rf[n][2] for n in names]; x=np.arange(3); w=0.26
    ax[0].bar(x-w,P,w,label="Precision",color="#92c5de"); ax[0].bar(x,Rc,w,label="Recall",color="#f4a582"); ax[0].bar(x+w,F1,w,label="F1",color="#b2182b")
    ax[0].set_xticks(x); ax[0].set_xticklabels(["Fixed","Logistic","RF"],fontsize=8); ax[0].set_ylim(0,1.05); ax[0].set_ylabel("Score")
    ax[0].legend(fontsize=6.5,ncol=3,loc="lower center",bbox_to_anchor=(0.5,1.0)); ax[0].set_title("(a) Detection",fontsize=8,pad=14)
    fi=rf["feature_importance"][:8][::-1]
    ax[1].barh(range(len(fi)),[f[1] for f in fi],color="#2166ac"); ax[1].set_yticks(range(len(fi))); ax[1].set_yticklabels([f[0] for f in fi],fontsize=7)
    ax[1].set_xlabel("RF importance"); ax[1].set_title("(b) Feature importance",fontsize=8)
    plt.tight_layout(); plt.savefig(f"{F}/fig_rf.pdf"); plt.close()

def fig_sparse():
    d=J("sparse_hough.json"); Ns=[r["N"] for r in d]; fig,a1=plt.subplots(figsize=(3.4,2.6))
    a1.plot(Ns,[r["speedup"] for r in d],marker="*",ms=9,lw=2,color="#b2182b")
    a1.set_xscale("log",base=2); a1.set_xlabel("Signal length $N$"); a1.set_ylabel("Scatter speedup ($\\times$)",color="#b2182b")
    a1.tick_params(axis="y",labelcolor="#b2182b"); a1.set_ylim(0,7)
    a2=a1.twinx(); a2.plot(Ns,[100*r["support"] for r in d],marker="o",ms=5,lw=1.4,color="#2166ac")
    a2.set_ylabel("DT-SCA support (%)",color="#2166ac"); a2.tick_params(axis="y",labelcolor="#2166ac"); a2.grid(False)
    plt.tight_layout(); plt.savefig(f"{F}/fig_sparse.pdf"); plt.close()

def fig_closely():
    cs=J("closely_spaced.json")["sep_sir"]; seps=sorted([float(k) for k in cs],reverse=True)
    plt.figure(figsize=(3.4,2.6)); plt.errorbar(seps,[cs[f"{x:.2f}"][0] for x in seps],yerr=[cs[f"{x:.2f}"][1] for x in seps],marker="s",ms=6,lw=1.8,color="#33a02c",capsize=3)
    plt.gca().invert_xaxis(); plt.xlabel(r"Chirp-rate separation $\Delta\beta N$"); plt.ylabel("Mean SIR (dB)"); plt.ylim(0,9)
    plt.tight_layout(); plt.savefig(f"{F}/fig_closely.pdf"); plt.close()

def fig_vehicular():
    v=J("vehicular.json"); fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
    fds=sorted([float(k) for k in v["doppler"]])
    for key,mk,c in [("Proposed","*","#b2182b"),("SOBI","s","#2166ac")]:
        ax[0].errorbar(fds,[v["doppler"][f"{f:.2f}"][key][0] for f in fds],yerr=[v["doppler"][f"{f:.2f}"][key][1] for f in fds],marker=mk,ms=8 if key=="Proposed" else 5,lw=1.8 if key=="Proposed" else 1.2,color=c,capsize=3,label=key)
    ax[0].set_xlabel(r"Max Doppler $f_dT_s$"); ax[0].set_ylabel("Mean SIR (dB)"); ax[0].set_title("(a) Doppler",fontsize=8); ax[0].legend(fontsize=7)
    mms=sorted([float(k) for k in v["array"]])
    for key,mk,c in [("Proposed","*","#b2182b"),("SOBI","s","#2166ac")]:
        ax[1].errorbar(mms,[v["array"][f"{m:.2f}"][key][0] for m in mms],yerr=[v["array"][f"{m:.2f}"][key][1] for m in mms],marker=mk,ms=8 if key=="Proposed" else 5,lw=1.8 if key=="Proposed" else 1.2,color=c,capsize=3,label=key)
    ax[1].set_xlabel(r"ULA mismatch $\varepsilon$"); ax[1].set_ylabel("Mean SIR (dB)"); ax[1].set_title("(b) Non-ideal array",fontsize=8); ax[1].legend(fontsize=7)
    plt.tight_layout(); plt.savefig(f"{F}/fig_vehicular.pdf"); plt.close()

def fig_realistic():
    r=J("realistic.json"); ser=r["ser"]; ub=r["ubss"]; fig,ax=plt.subplots(1,2,figsize=(6.9,2.6))
    ss=sorted(int(x) for x in ser)
    for name,mk,c in [("unproc","o","#888888"),("SOBI","s","#2166ac"),("Proposed","*","#b2182b")]:
        ax[0].plot(ss,[ser[str(x)][name][0] for x in ss],marker=mk,ms=7 if name=="Proposed" else 5,lw=1.8 if name=="Proposed" else 1.2,color=c,label="Unprocessed" if name=="unproc" else name)
    ax[0].set_xlabel("SNR (dB)"); ax[0].set_ylabel("Mean SER"); ax[0].set_title("(a) CSS over Rician fading",fontsize=8); ax[0].legend(fontsize=7)
    us=sorted(int(x) for x in ub["Proposed"])
    ax[1].semilogy(us,[ub["Proposed"][str(x)][0] for x in us],marker="*",ms=8,lw=1.8,color="#b2182b",label="Proposed")
    ax[1].semilogy(us,[ub["Bofill"][str(x)][0] for x in us],marker="^",ms=5,lw=1.2,color="#2166ac",label="Bofill-Zibulevsky")
    ax[1].set_xlabel("SNR (dB)"); ax[1].set_ylabel(r"$1-\cos$"); ax[1].set_title("(b) Underdet. matrix ID",fontsize=8); ax[1].legend(fontsize=7)
    plt.tight_layout(); plt.savefig(f"{F}/fig_realistic.pdf"); plt.close()

def fig_genfm():
    d=J("genfm.json"); S=d["snrs"]
    sty={"SOBI":("s",":","#2166ac"),"JD":("x",":","#999999"),"Dechirp-refine":("v","--","#d6604d"),"Ridge-refine":("^","-.","#f4a582"),"SST-refine":("*","-","#b2182b")}
    fig,ax=plt.subplots(1,2,figsize=(6.9,2.7))
    for k in d["keys"]:
        mk,ls,c=sty[k]; lw=2.2 if "SST" in k else 1.1; ms=9 if "SST" in k else 4
        ax[0].plot(S,[d["all3"][k][str(x)][0] for x in S],marker=mk,ls=ls,color=c,lw=lw,ms=ms,label=k)
        ax[1].plot(S,[d["fm"][k][str(x)][0] for x in S],marker=mk,ls=ls,color=c,lw=lw,ms=ms,label=k)
    ax[0].set_title("(a) All sources",fontsize=8); ax[1].set_title("(b) Nonlinear-FM sources only",fontsize=8)
    for q in ax: q.set_xlabel("Input SNR (dB)"); q.set_ylabel("Mean SIR (dB)")
    ax[1].legend(fontsize=6,loc="lower right"); plt.tight_layout(); plt.savefig(f"{F}/fig_genfm.pdf"); plt.close()

def fig_gain():
    d=J("gain_sweep.json"); Ws=d["W"]; plt.figure(figsize=(3.5,2.7))
    plt.plot(Ws,d["ref_NW"],"k--",lw=1.1,label=r"$10\log_{10}(N/W)$ bound")
    for snr,mk,c in [("10","o","#2166ac"),("20","*","#b2182b")]:
        if snr in d["gain"]:
            plt.plot(Ws,d["gain"][snr],marker=mk,ms=7 if snr=="20" else 5,lw=1.8,color=c,label=f"measured, {snr} dB")
    plt.xscale("log",base=2); plt.xlabel("Kept bandwidth $W$ (bins)"); plt.ylabel(r"$\Delta$SIR (dB)")
    plt.legend(fontsize=6.3); plt.tight_layout(); plt.savefig(f"{F}/fig_gain.pdf"); plt.close()

def fig_hough():
    from scipy.signal import stft
    from proposed import whiten_subspace, dt_sca_support, sparse_wht_grid, hough_features
    import algo as A
    clf=pickle.load(open(f"{HERE}/rf_cached.pkl","rb")); rng=np.random.default_rng(3)
    x,S,Am=A.make_chirp_mixture(3,3,512,8,rng,noise_src=0); z,W,ns,_=whiten_subspace(x,force_dim=3)
    Xf=np.zeros((3,)+stft(x[0],nperseg=64,noverlap=48,return_onesided=False)[2].shape,dtype=complex)
    for i in range(3): Xf[i]=stft(x[i],nperseg=64,noverlap=48,return_onesided=False)[2]
    mask=dt_sca_support(Xf,alpha1=0.03,alpha2=0.55,window=1); WHT,_,_=sparse_wht_grid(z,mask,n_f0=32,n_beta=32,L=24)
    p=clf.predict_proba(np.nan_to_num(hough_features(WHT,win=3).reshape(-1,12)))[:,1].reshape(WHT.shape)
    fig,ax=plt.subplots(1,2,figsize=(6.8,2.7))
    im0=ax[0].imshow(np.abs(WHT),aspect="auto",origin="lower",cmap="viridis"); ax[0].set_title(r"(a) Sparse Wigner--Hough $|\widehat{\mathrm{WHT}}|$",fontsize=8)
    ax[0].set_xlabel(r"$\beta$ index"); ax[0].set_ylabel(r"$f_0$ index"); fig.colorbar(im0,ax=ax[0],fraction=0.046)
    im1=ax[1].imshow(p,aspect="auto",origin="lower",cmap="magma",vmin=0,vmax=1); ax[1].set_title(r"(b) RF posterior $\hat p$",fontsize=8)
    ax[1].set_xlabel(r"$\beta$ index"); ax[1].set_ylabel(r"$f_0$ index"); fig.colorbar(im1,ax=ax[1],fraction=0.046)
    plt.tight_layout(); plt.savefig(f"{F}/fig_hough.pdf"); plt.close()

ALL=[fig_sir_snr,fig_refine,fig_underdet,fig_rf,fig_sparse,fig_closely,fig_vehicular,fig_realistic,fig_genfm,fig_gain,fig_hough]
if __name__=="__main__":
    for fn in ALL:
        try: fn(); print("ok",fn.__name__)
        except Exception as e: print("FAIL",fn.__name__,repr(e)[:100])
    print("figures in",F)

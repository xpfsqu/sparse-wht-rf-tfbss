"""
realdata.py — semi-real validation using a genuinely MEASURED signal.

We mix synthetic target chirps with a REAL recorded non-stationary interferer
(an excerpt of the MIT-BIH arrhythmia ECG, the same measured record scipy ships,
cloned from github.com/scipy/dataset-ecg), separate the mixture, and report the
chirp-target SIR. A generic loader `load_real_source` lets a real radar/comm
chirp capture (.npy/.wav) be dropped in instead.
"""
import os, sys, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import hilbert
import algo as A

def load_real_source(path):
    """Load a real recording (.npy or .wav) as a 1-D complex (analytic) signal."""
    if path.endswith(".npy"): raw=np.load(path).astype(float).ravel()
    elif path.endswith(".wav"):
        from scipy.io import wavfile; _,raw=wavfile.read(path); raw=raw.astype(float).ravel()
    else: raw=np.fromfile(path,dtype=np.int16).astype(float)
    raw=raw-raw.mean()
    return hilbert(raw)                      # analytic -> complex

def real_segments(path, N, nseg, hop=None):
    z=load_real_source(path); hop=hop or N
    segs=[]
    for i in range(nseg):
        a=i*hop
        if a+N>len(z): break
        s=z[a:a+N]; s=s/(np.linalg.norm(s)+1e-12)*np.sqrt(N); segs.append(s)
    return segs

def make_hybrid_mixture(real_seg, N, snr, rng):
    """2 synthetic chirps (targets) + 1 REAL measured interferer."""
    t=np.arange(N)
    s1=np.exp(1j*(2*np.pi*(0.08*t+0.5*(0.18/N)*t*t)+rng.uniform(0,2*np.pi)))
    s2=np.exp(1j*(2*np.pi*(0.28*t+0.5*(0.42/N)*t*t)+rng.uniform(0,2*np.pi)))
    S=np.array([s1,s2,real_seg],dtype=complex)
    S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
    Am=A.random_mixing(3,3,rng); xc=Am@S; p=np.mean(np.abs(xc)**2); npw=p/(10**(snr/10))
    x=xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
    return x,S,Am

if __name__=="__main__":
    import json
    default=os.path.join(HERE,"..","data","ecg.dat")
    path=sys.argv[1] if len(sys.argv)>1 else (default if os.path.exists(default) else "/tmp/ecg_real.npy")
    N=512; segs=real_segments(path,N,60)
    print(f"Loaded {len(segs)} real segments from {os.path.basename(path)}")
    print("Hybrid mixture (2 target chirps + 1 REAL measured interferer):")
    print("  chirp-target SIR and real-source SIR, SOBI vs Proposed")
    out={"snrs":[],"chirp_SOBI":[],"chirp_Prop":[],"real_SOBI":[],"real_Prop":[]}
    for snr in (0,5,10,15,20):
        cso=[];cpr=[];rso=[];rpr=[]
        for i,seg in enumerate(segs[:50]):
            rng=np.random.default_rng(13000+i); x,S,Am=make_hybrid_mixture(seg,N,snr,rng)
            ss=A.sobi(x,3).astype(complex); pp=A.determined_refined(x,3)[0].astype(complex)
            cso.append(A.sir_complex(S[:2],ss[:2])); cpr.append(A.sir_complex(S[:2],pp[:2]))
            rso.append(A.sir_complex(S[2:],ss[2:3] if ss.shape[0]>2 else ss)); rpr.append(A.sir_complex(S[2:],pp[2:3]))
        out["snrs"].append(snr)
        out["chirp_SOBI"].append(float(np.mean(cso))); out["chirp_Prop"].append(float(np.mean(cpr)))
        out["real_SOBI"].append(float(np.mean(rso))); out["real_Prop"].append(float(np.mean(rpr)))
        print(f"  SNR={snr:2d}: chirp SOBI={np.mean(cso):5.2f} Prop={np.mean(cpr):5.2f} | real-src SOBI={np.mean(rso):5.2f} Prop={np.mean(rpr):5.2f}")
    json.dump(out,open(os.path.join(HERE,"..","results","final","realdata.json"),"w"),indent=2)
    print("saved realdata.json")

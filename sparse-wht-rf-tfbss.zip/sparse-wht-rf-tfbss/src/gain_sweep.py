"""gain_sweep.py — reproduce the refinement processing-gain sweep (fig_gain).
Measures the refinement SIR gain vs kept bandwidth W and compares to 10log10(N/W)."""
import os, sys, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import algo as A

def dechirp_refine_bw(s, nb):
    s=np.asarray(s,dtype=complex); N=len(s); t=np.arange(N)
    bg=np.linspace(-0.6,0.6,96)/N; best=(-1,0)
    for b in bg:
        pk=np.max(np.abs(np.fft.fft(s*np.exp(-1j*np.pi*b*t*t))))
        if pk>best[0]: best=(pk,b)
    b=best[1]; dd=s*np.exp(-1j*np.pi*b*t*t); F=np.fft.fft(dd); k=int(np.argmax(np.abs(F)))
    mask=np.zeros(N,bool); mask[(k+np.arange(-nb,nb+1))%N]=True
    return np.fft.ifft(F*mask)*np.exp(1j*np.pi*b*t*t)

def run(N=512, T=40):
    Ws=[3,5,9,17,33,49,65,97,129,193,257]
    out={"W":Ws,"ref_NW":[float(10*np.log10(N/w)) for w in Ws],"gain":{}}
    for snr in (10,20):
        g=[]
        for w in Ws:
            nb=(w-1)//2; gg=[]
            for tr in range(T):
                rng=np.random.default_rng(4000+tr); x,S,Am=A.make_chirp_mixture(3,3,N,snr,rng,noise_src=1)
                jj=A.determined_v2(x,3)[0].astype(complex); base=A.sir_complex(S[:2],jj[:2])
                rr=np.array([dechirp_refine_bw(jj[i],nb) for i in range(3)])
                gg.append(A.sir_complex(S[:2],rr[:2])-base)
            g.append(float(np.mean(gg)))
        out["gain"][str(snr)]=g
        print(f"SNR={snr}: "+" ".join(f"{w}:{v:.1f}" for w,v in zip(Ws,g)))
    json.dump(out,open(os.path.join(HERE,"..","results","final","gain_sweep.json"),"w"),indent=2)
    print("saved gain_sweep.json"); return out

if __name__=="__main__": run()

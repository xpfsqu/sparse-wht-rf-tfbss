"""
sparse_wht_fast.py — scatter-based sparse Wigner-Hough integrator.

Dense line integral:   WHT(f0,beta) = sum_t W(f0+beta*t, t)      O(G_f0 * G_beta * N)
Scatter (sparse) form: each retained TF point (f,t) with value w lies on the line
f0 = f - beta*t for every beta, so it is scattered into cells (f0=f-beta*t, beta).
Cost O(|Omega| * G_beta). When |Omega| << G_f0 * N this is strictly faster and
returns exactly the support-restricted integral (not an approximation).
"""
import os, sys, time, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
from scipy.signal import stft
from proposed import whiten_subspace, dt_sca_support, _wvd_pseudo
import algo as A

def _wvd_sum_and_mask(x,n=3,L=24,alpha1=0.05,alpha2=0.60,nperseg=128,noverlap=112):
    m,N=x.shape; z,W,ns,_=whiten_subspace(x,force_dim=min(m,n))
    Wsum=np.zeros((2*L+1,N))
    for k in range(z.shape[0]): Wsum+=_wvd_pseudo(z[k],L)
    X=A._mc_stft(x,nperseg,noverlap); mask=dt_sca_support(X,alpha1=alpha1,alpha2=alpha2,window=1)
    # resample STFT mask onto the (2L+1, N) WVD grid
    nf_m,nt_m=mask.shape
    fi=np.clip(np.linspace(0,nf_m-1,2*L+1).astype(int),0,nf_m-1)
    ti=np.clip(np.linspace(0,nt_m-1,N).astype(int),0,nt_m-1)
    mask_w=mask[np.ix_(fi,ti)]
    return Wsum,mask_w,N,L

def hough_dense(Wsum,n_f0,n_beta,L,N):
    """Dense line integral using integer row-shift arithmetic.
    f0 grid = WVD rows L..L+n_f0-1 (normalized freq 0..0.5); row shift for (beta,t)
    is s=round(beta*t*2L)."""
    beta=np.linspace(-0.5,0.5,n_beta)/N
    tax=np.arange(N); WHT=np.zeros((n_f0,n_beta))
    for j,b in enumerate(beta):
        s=np.round(b*tax*(2*L)).astype(int)         # integer row shift per time
        for i in range(n_f0):
            r=(L+i)+s                                 # WVD row read at each t
            ok=(r>=0)&(r<=2*L)
            WHT[i,j]=Wsum[r[ok],tax[ok]].sum()
    return WHT

def hough_scatter(Wsum,mask_w,n_f0,n_beta,L,N):
    """Sparse scatter integrator: exact inverse of hough_dense, visits only
    retained points. O(|Omega|*G_beta)."""
    beta=np.linspace(-0.5,0.5,n_beta)/N
    WHT=np.zeros((n_f0,n_beta))
    fr,tc=np.where(mask_w); w=Wsum[fr,tc]
    for j,b in enumerate(beta):
        s=np.round(b*tc*(2*L)).astype(int)
        i=fr-s-L                                      # exact inverse of dense
        ok=(i>=0)&(i<n_f0)
        np.add.at(WHT[:,j],i[ok],w[ok])
    return WHT

def benchmark(trials=6):
    rows=[]
    for N in (256,512,1024,2048,4096):
        td=ts=0.0; kap=0.0; relerr=0.0
        for tr in range(trials):
            rng=np.random.default_rng(100+tr)
            x,S,Amat=A.make_chirp_mixture(3,3,N,10,rng,noise_src=1)
            Wsum,mask_w,N_,L=_wvd_sum_and_mask(x)
            kap+=mask_w.mean()
            t0=time.time(); Hd=hough_dense(Wsum,25,32,L,N); td+=time.time()-t0
            t0=time.time(); Hs=hough_scatter(Wsum,mask_w,25,32,L,N); ts+=time.time()-t0
            # accuracy vs dense-over-support (mask the dense then compare)
            Hd_sup=hough_dense(Wsum*mask_w,25,32,L,N)
            relerr+=np.linalg.norm(Hs-Hd_sup)/(np.linalg.norm(Hd_sup)+1e-12)
        td/=trials; ts/=trials; kap/=trials; relerr/=trials
        rows.append({"N":N,"support":float(kap),"dense_s":td,"scatter_s":ts,
                     "speedup":td/max(ts,1e-9),"relerr_vs_support":float(relerr)})
        print(f"N={N:4d} support={kap:.1%} dense={td*1e3:6.1f}ms scatter={ts*1e3:6.1f}ms "
              f"speedup={td/max(ts,1e-9):5.2f}x relerr={relerr:.2e}")
    json.dump(rows,open(os.path.join(HERE,"..","results","final","sparse_hough.json"),"w"),indent=2)
    return rows

if __name__=="__main__": benchmark()

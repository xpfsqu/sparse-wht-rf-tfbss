"""
realistic.py — stronger, more realistic experiments for the TSP version.
 (A) End-to-end LoRa-style chirp-spread-spectrum (CSS) over Rician-fading
     channels: symbol-error rate (SER) before vs after separation, vs SOBI.
 (B) Underdetermined mixing-matrix estimation vs a classic UBSS baseline
     (Bofill-Zibulevsky potential-function clustering).
All numbers real. Writes results/final/realistic.json.
"""
import os, sys, json, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import algo as A
from proposed import dt_sca_support, whiten_subspace

# ---------------- Rician fading mixing ----------------
def rician_mixing(m,n,rng,Kf=4.0):
    th=rng.uniform(-np.pi/3,np.pi/3,n); A_=np.zeros((m,n),complex)
    for k in range(n):
        los=np.exp(1j*np.pi*np.arange(m)*np.sin(th[k]))
        nlos=(rng.standard_normal(m)+1j*rng.standard_normal(m))/np.sqrt(2)
        a=np.sqrt(Kf/(Kf+1))*los+np.sqrt(1/(Kf+1))*nlos
        A_[:,k]=a/(np.linalg.norm(a)+1e-12)
    return A_

# ---------------- LoRa-style CSS ----------------
def css_base(M):
    n=np.arange(M); return np.exp(1j*2*np.pi*(0.5*n*n/M))   # up-chirp
def css_frame(syms,M):
    up=css_base(M); n=np.arange(M); out=[]
    for s in syms: out.append(up*np.exp(1j*2*np.pi*s*n/M))
    return np.concatenate(out)
def css_demod(x,M,nsym):
    dn=np.conj(css_base(M)); est=[]
    for i in range(nsym):
        seg=x[i*M:(i+1)*M]
        if len(seg)<M: seg=np.pad(seg,(0,M-len(seg)))
        est.append(int(np.argmax(np.abs(np.fft.fft(seg*dn)))))
    return np.array(est)

def ser_experiment(T=30,SF=6,nsym=12,Kf=4.0):
    M=2**SF; N=M*nsym; SNRS=[0,5,10,15,20]; nuser=3
    res={s:{"unproc":[],"SOBI":[],"Proposed":[]} for s in SNRS}
    for s in SNRS:
        for tr in range(T):
            rng=np.random.default_rng(31000+tr)
            syms=[rng.integers(0,M,nsym) for _ in range(nuser)]
            S=np.array([css_frame(sy,M) for sy in syms],dtype=complex)
            S/=(np.linalg.norm(S,axis=1,keepdims=True)+1e-12); S*=np.sqrt(N)
            Am=rician_mixing(nuser,nuser,rng,Kf); xc=Am@S
            p=np.mean(np.abs(xc)**2); npw=p/(10**(s/10))
            x=xc+(rng.standard_normal(xc.shape)+1j*rng.standard_normal(xc.shape))*np.sqrt(npw/2)
            # unprocessed: demod antenna 0 directly
            def ser_of(est_list):
                err=tot=0
                # match estimated sources to true users by symbol agreement
                return est_list
            # unprocessed (fair, all-user avg): each user -> its best single antenna, no reuse
            estA=[[css_demod(x[a],M,nsym) for a in range(nuser)]]
            used=set(); sers=[]
            for u in range(nuser):
                best=1.0; bj=None
                for a in range(nuser):
                    if a in used: continue
                    e=np.mean(css_demod(x[a],M,nsym)!=syms[u])
                    if e<best: best=e; bj=a
                if bj is not None: used.add(bj)
                sers.append(best)
            res[s]["unproc"].append(float(np.mean(sers)))
            # separate + per-source demod, match each true user to best recovered row (all-user avg)
            for name,Sep in [("SOBI",A.sobi(x,nuser)),("Proposed",A.determined_refined(x,nuser)[0])]:
                est=[css_demod(Sep[r].astype(complex),M,nsym) for r in range(Sep.shape[0])]
                used=set(); sers=[]
                for u in range(nuser):
                    best=1.0; bj=None
                    for j in range(len(est)):
                        if j in used: continue
                        e=np.mean(est[j]!=syms[u])
                        if e<best: best=e; bj=j
                    if bj is not None: used.add(bj)
                    sers.append(best)
                res[s][name].append(float(np.mean(sers)))
    out={s:{k:[float(np.mean(v)),float(np.std(v))] for k,v in res[s].items()} for s in SNRS}
    print("=== CSS SER over Rician fading (SF=%d, %d users) ==="%(SF,nuser))
    for s in SNRS: print(f"  SNR={s:2d} unproc={out[s]['unproc'][0]:.3f} SOBI={out[s]['SOBI'][0]:.3f} Proposed={out[s]['Proposed'][0]:.3f}")
    return out

# ---------------- UBSS baseline: Bofill-Zibulevsky potential ----------------
def bofill_estimate(x,n,nperseg=128,noverlap=112,alpha1=0.05,alpha2=0.60,nbins=180,sigma=3.0):
    """Estimate n mixing directions (m=2) by potential-function peak picking on
    the angle histogram of single-source STFT columns."""
    m,N=x.shape; X=A._mc_stft(x,nperseg,noverlap)
    mask=dt_sca_support(X,alpha1=alpha1,alpha2=alpha2,window=1)
    idx=np.argwhere(mask); ang=[]; wgt=[]
    for (fi,ti) in idx:
        v=X[:,fi,ti]; nr=np.linalg.norm(v)
        if nr>1e-9:
            v=v*np.exp(-1j*np.angle(v[0]+1e-12))      # phase-anchor
            ang.append(np.arctan2(np.abs(v[1]),np.abs(v[0]))); wgt.append(nr)
    ang=np.array(ang); wgt=np.array(wgt)
    grid=np.linspace(0,np.pi/2,nbins); pot=np.zeros(nbins)
    for a_,w_ in zip(ang,wgt): pot+=w_*np.exp(-((grid-a_)**2)/(2*(sigma*np.pi/180)**2))
    # pick n local maxima
    peaks=[]
    for i in range(1,nbins-1):
        if pot[i]>=pot[i-1] and pot[i]>=pot[i+1]: peaks.append((pot[i],grid[i]))
    peaks=sorted(peaks,reverse=True)[:n]
    if len(peaks)<n: peaks+=[(0,grid[np.argmax(pot)])]*(n-len(peaks))
    A_=np.array([[np.cos(a) for _,a in peaks],[np.sin(a) for _,a in peaks]],dtype=complex)
    return A_/ (np.linalg.norm(A_,axis=0,keepdims=True)+1e-12)

def ubss_baseline_cmp(T=60):
    SNRS=[0,5,10,15,20]; out={"Proposed":{},"Bofill":{}}
    import pickle
    clf=pickle.load(open(os.path.join(HERE,"rf_cached.pkl"),"rb"))
    for s in SNRS:
        pe=[]; be=[]
        for tr in range(T):
            rng=np.random.default_rng(6000+tr); x,S,Am=A.make_chirp_mixture(2,3,512,s,rng,noise_src=1)
            try:
                _,Ah,_=A.separate_underdet(x,3,clf); pe.append(A.mix_err(Am,Ah))
            except Exception: pass
            try:
                Ab=bofill_estimate(x,3); be.append(A.mix_err(Am,Ab))
            except Exception: pass
        out["Proposed"][s]=[float(np.mean(pe)),float(np.std(pe))]; out["Bofill"][s]=[float(np.mean(be)),float(np.std(be))]
        print(f"  SNR={s:2d} Proposed mixErr={np.mean(pe):.3f}  Bofill mixErr={np.mean(be):.3f}")
    return out

if __name__=="__main__":
    OUT=os.path.join(HERE,"..","results","final"); os.makedirs(OUT,exist_ok=True)
    ser=ser_experiment()
    print("=== Underdetermined mixing-matrix: Proposed vs Bofill-Zibulevsky UBSS ===")
    ub=ubss_baseline_cmp()
    json.dump({"ser":ser,"ubss":ub},open(f"{OUT}/realistic.json","w"),indent=2)
    print("saved realistic.json")
